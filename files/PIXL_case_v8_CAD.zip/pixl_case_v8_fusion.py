# PIXL watch case v8 — the OLED module goes in from the back, so nothing may stand inside its 44x27 outline:
# two M2 screws sit in the bottom strip (below the PCB, beside the DS3231) and the top edge of the back cover
# hooks into a groove in the top wall (tilt the cover in, hook first, then screw the bottom).
# v7: solid webs tying every screw boss to the wall(s), thinned key hinges.
# v6 notes: v5 layout with small, low strap lugs (the spring bar sits next to the back, close to the wrist)
# and FOUR M2 screws: bosses in the top-right and bottom-left corners plus two on the side walls
# (the other two corners hold the battery and the XIAO).
#   top row: Li-Po 30x20x5 + vibration motor          bottom row: XIAO ESP32-S3 + DS3231
#   piezo disc glued inside the back cover (Casio style, the thin back resonates), XIAO taped under the module PCB.
#   A strip of front panel below the screen carries the PIXL dot-block wordmark and a Bayer dither bar.
# Fusion 360 API script. Millimetres. Z = 0 is the bottom of the OLED module PCB (module STEP at origin).
import adsk.core, adsk.fusion, math

PCB_T = 1.6
WALL = 2.0
IN_X, IN_T, IN_B = 22.2, 13.7, -25.5           # inner cavity: x +-22.2, y from IN_B to IN_T
OUT_X, OUT_T, OUT_B = IN_X + WALL, IN_T + WALL, IN_B - WALL
R_OUT, R_IN = 5.0, 1.7
Z_TOP, Z_CAV, Z_TAB = 5.3, 2.8, 4.35
Z_BOT = -6.5                                    # DS3231 (6.2) sets the layer height
COVER_T = 1.2
WIN = (-16.3, -6.6, 7.0, 6.4)
WIN_CHAMFER = 1.2
KEY_Y = [8.70, 3.03, -2.63, -8.30]
KEY_ICONS = ['up', 'down', 'menu', 'back']
ICON_X = 16.9
HOLES = [(-20.5, -12.0), (-20.5, 12.0), (20.5, -12.0), (20.5, 12.0)]
LUG_IN, LUG_W, LUG_LEN = 10.2, 2.4, 4.6
LUG_Z0, LUG_Z1 = Z_BOT - 1.2, Z_BOT + 3.0      # flush with the back, 4.2 mm tall
BAR_OFF, BAR_Z, BAR_D = 2.8, Z_BOT + 0.3, 1.1
SCREW_OFF = 1.7
BAT = (-21.6, -6.9, 8.4, 13.1)
VIB = (15.5, 4.0, 5.0)
XIAO = (0.6, -24.9, 21.6, -7.1)                 # taped under the module PCB, components facing down, USB-C right
RTC = (-18.0, -24.9, -4.0, -10.9)
PIEZO = (11.0, -15.3, 10.0)                    # 20 mm disc on the inside of the back cover
USB_Y, USB_Z = (XIAO[1] + XIAO[3]) / 2, -0.3 - 1.0 - 1.6
STRIP_Y = (IN_B + (-13.7)) / 2 - 0.4            # centre line of the decorated strip below the screen
BOSSES = [(-20.1, -23.4, 2.0), (-1.7, -23.5, 1.9)]   # x, y, boss radius — both outside the module PCB (y < -13.5) and the XIAO
HOOK = (11.0, 19.0)                             # x span of the cover hook on the top edge
PILOT_R = 0.85
BAYER = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5]
PIXL_G = [["1110", "1001", "1001", "1110", "1000", "1000"], ["1", "0", "1", "1", "1", "1"],
          ["1001", "1001", "0110", "0110", "1001", "1001"], ["1000", "1000", "1000", "1000", "1000", "1111"]]


def mm(v): return v / 10.0
def P(x, y, z=0.0): return adsk.core.Point3D.create(mm(x), mm(y), mm(z))
def V(v): return adsk.core.ValueInput.createByReal(mm(v))


def run(_context: str):
    app = adsk.core.Application.get()
    design = adsk.fusion.Design.cast(app.activeProduct)
    root = design.rootComponent
    NEW = adsk.fusion.FeatureOperations.NewBodyFeatureOperation
    JOIN = adsk.fusion.FeatureOperations.JoinFeatureOperation
    CUT = adsk.fusion.FeatureOperations.CutFeatureOperation
    for i in range(root.occurrences.count - 1, -1, -1):
        o = root.occurrences.item(i)
        if o.component.name.startswith('PIXL') or o.component.name.startswith('Internals'):
            o.deleteMe()

    def new_comp(name):
        occ = root.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        occ.component.name = name
        return occ.component

    def plane(comp, z):
        if abs(z) < 1e-9:
            return comp.xYConstructionPlane
        pi = comp.constructionPlanes.createInput()
        pi.setByOffset(comp.xYConstructionPlane, V(z))
        p = comp.constructionPlanes.add(pi)
        p.isLightBulbOn = False
        return p

    def extrude(comp, prof, h, op, body=None):
        ei = comp.features.extrudeFeatures.createInput(prof, op)
        ei.setDistanceExtent(False, V(h))
        if body is not None and op != NEW:
            ei.participantBodies = [body]
        return comp.features.extrudeFeatures.add(ei)

    def all_profiles(sk, pick=None):
        oc = adsk.core.ObjectCollection.create()
        for p in sk.profiles:
            if pick is None or pick(p):
                oc.add(p)
        return oc

    def box(comp, x0, y0, z0, x1, y1, z1, op, body=None):
        sk = comp.sketches.add(plane(comp, z0))
        sk.sketchCurves.sketchLines.addTwoPointRectangle(P(x0, y0), P(x1, y1))
        f = extrude(comp, sk.profiles.item(0), z1 - z0, op, body)
        return f.bodies.item(0) if op == NEW else body

    def cyl(comp, cx, cy, z0, z1, r, op, body=None):
        sk = comp.sketches.add(plane(comp, z0))
        sk.sketchCurves.sketchCircles.addByCenterRadius(P(cx, cy), mm(r))
        f = extrude(comp, sk.profiles.item(0), z1 - z0, op, body)
        return f.bodies.item(0) if op == NEW else body

    def vedges(body, pts, tol=0.05):
        oc = adsk.core.ObjectCollection.create()
        for e in body.edges:
            g = e.geometry
            if not isinstance(g, adsk.core.Line3D):
                continue
            s, t = g.startPoint, g.endPoint
            if abs(s.x - t.x) > 1e-6 or abs(s.y - t.y) > 1e-6:
                continue
            for (x, y) in pts:
                if abs(s.x * 10 - x) < tol and abs(s.y * 10 - y) < tol:
                    oc.add(e)
        return oc

    def fillet(comp, edges, r):
        if edges.count == 0:
            return
        fi = comp.features.filletFeatures.createInput()
        fi.addConstantRadiusEdgeSet(edges, V(r), True)
        comp.features.filletFeatures.add(fi)

    def face_at_z(body, z):
        best = None
        for f in body.faces:
            g = f.geometry
            if isinstance(g, adsk.core.Plane) and abs(abs(g.normal.z) - 1) < 1e-6 and abs(f.boundingBox.maxPoint.z * 10 - z) < 0.01:
                if best is None or f.area > best.area:
                    best = f
        return best

    def loop_edges(lp):
        oc = adsk.core.ObjectCollection.create()
        for e in lp.edges:
            oc.add(e)
        return oc

    def outer_loop(face):
        for i in range(face.loops.count):
            if face.loops.item(i).isOuter:
                return face.loops.item(i)

    def poly(sk, pts):
        L = sk.sketchCurves.sketchLines
        for i in range(len(pts)):
            L.addByTwoPoints(P(*pts[i]), P(*pts[(i + 1) % len(pts)]))

    def rect(sk, x0, y0, x1, y1):
        sk.sketchCurves.sketchLines.addTwoPointRectangle(P(x0, y0), P(x1, y1))

    def bar(sk, a, b, w):
        dx, dy = b[0] - a[0], b[1] - a[1]; L = math.hypot(dx, dy); nx, ny = -dy / L * w / 2, dx / L * w / 2
        ex, ey = dx / L * w * 0.35, dy / L * w * 0.35
        poly(sk, [(a[0] - ex + nx, a[1] - ey + ny), (b[0] + ex + nx, b[1] + ey + ny), (b[0] + ex - nx, b[1] + ey - ny), (a[0] - ex - nx, a[1] - ey - ny)])

    def rrect(sk, cx, cy, w, h, r):
        L, A = sk.sketchCurves.sketchLines, sk.sketchCurves.sketchArcs
        x0, x1, y0, y1 = cx - w / 2, cx + w / 2, cy - h / 2, cy + h / 2
        L.addByTwoPoints(P(x0 + r, y0), P(x1 - r, y0)); L.addByTwoPoints(P(x1, y0 + r), P(x1, y1 - r))
        L.addByTwoPoints(P(x1 - r, y1), P(x0 + r, y1)); L.addByTwoPoints(P(x0, y1 - r), P(x0, y0 + r))
        for (ax, ay, s) in [(x1 - r, y0 + r, -math.pi / 2), (x1 - r, y1 - r, 0), (x0 + r, y1 - r, math.pi / 2), (x0 + r, y0 + r, math.pi)]:
            A.addByCenterStartSweep(P(ax, ay), P(ax + r * math.cos(s), ay + r * math.sin(s)), math.pi / 2)

    def cut_sketch(comp, body, sk, depth, pick=None):
        ei = comp.features.extrudeFeatures.createInput(all_profiles(sk, pick), CUT)
        ei.setDistanceExtent(False, V(depth))
        ei.participantBodies = [body]
        comp.features.extrudeFeatures.add(ei)

    corners_out = [(x, y) for x in (-OUT_X, OUT_X) for y in (OUT_B, OUT_T)]
    corners_in = [(x, y) for x in (-IN_X, IN_X) for y in (IN_B, IN_T)]

    # =============== SHELL ===============
    sh = new_comp('PIXL Shell v8')
    body = box(sh, -OUT_X, OUT_B, Z_BOT, OUT_X, OUT_T, Z_TOP, NEW)
    body.name = 'Shell'
    fillet(sh, vedges(body, corners_out), R_OUT)
    fillet(sh, loop_edges(outer_loop(face_at_z(body, Z_TOP))), 1.4)
    box(sh, -IN_X, IN_B, Z_BOT, IN_X, IN_T, Z_CAV, CUT, body)
    fillet(sh, vedges(body, corners_in), R_IN)
    box(sh, 11.0, -11.3, Z_CAV - 0.01, 20.7, 11.7, Z_TAB, CUT, body)
    box(sh, -10.8, 9.6, Z_CAV - 0.01, 10.0, 12.2, 3.7, CUT, body)
    S, TAB_HALF, X0, X1 = 0.6, 2.5, 11.5, 19.6
    for c in KEY_Y:
        box(sh, X0, c - TAB_HALF - S, Z_TAB - 0.01, X0 + S, c + TAB_HALF + S, Z_TOP + 0.1, CUT, body)
        box(sh, X0, c + TAB_HALF, Z_TAB - 0.01, X1, c + TAB_HALF + S, Z_TOP + 0.1, CUT, body)
        box(sh, X0, c - TAB_HALF - S, Z_TAB - 0.01, X1, c - TAB_HALF, Z_TOP + 0.1, CUT, body)
    HINGE_T = 0.5   # plastic left at the hinge (was 0.95 mm)
    for c in KEY_Y:
        box(sh, X1 - 1.2, c - TAB_HALF, Z_TAB - 0.01, 20.7, c + TAB_HALF, Z_TOP - HINGE_T, CUT, body)
    box(sh, WIN[0], WIN[1], Z_CAV - 0.01, WIN[2], WIN[3], Z_TOP + 0.1, CUT, body)
    top = face_at_z(body, Z_TOP)
    for i in range(top.loops.count):
        lp = top.loops.item(i)
        bb = lp.boundingBox
        if abs(bb.minPoint.x * 10 - WIN[0]) < 0.05 and abs(bb.maxPoint.y * 10 - WIN[3]) < 0.05:
            ci = sh.features.chamferFeatures.createInput2()
            ci.chamferEdgeSets.addEqualDistanceChamferEdgeSet(loop_edges(lp), V(WIN_CHAMFER), True)
            sh.features.chamferFeatures.add(ci)
            break
    for (x, y) in HOLES:
        cyl(sh, x, y, PCB_T, Z_CAV + 0.01, 1.5, JOIN, body)
        cyl(sh, x, y, 0.3, PCB_T + 0.01, 0.88, JOIN, body)
    # PIXL wordmark on the strip below the screen
    sk = sh.sketches.add(plane(sh, Z_TOP))
    cell = 1.1
    cols = sum(len(g[0]) for g in PIXL_G) + len(PIXL_G) - 1
    x0, ytop, cx = -11.0 - cols * cell / 2, STRIP_Y + 3 * cell, 0
    for g in PIXL_G:
        for r, row in enumerate(g):
            c = 0
            while c < len(row):
                if row[c] != '1':
                    c += 1; continue
                c0 = c
                while c < len(row) and row[c] == '1':
                    c += 1
                rect(sk, x0 + (cx + c0) * cell, ytop - (r + 1) * cell, x0 + (cx + c) * cell, ytop - r * cell)
        cx += len(g[0]) + 1
    cut_sketch(sh, body, sk, -0.4)
    # Bayer dither bar: tone fades from solid (left) to empty (right)
    sk = sh.sketches.add(plane(sh, Z_TOP))
    pitch, dot, ncol, nrow = 1.25, 0.75, 13, 4
    bx0, by0 = 2.5, STRIP_Y - (nrow - 1) * pitch / 2 - dot / 2
    for j in range(nrow):
        for i in range(ncol):
            tone = 1 - i / (ncol - 1)
            if BAYER[((j & 3) << 2) | (i & 3)] < round(tone * 16):
                x, y = bx0 + i * pitch, by0 + j * pitch
                rect(sk, x, y, x + dot, y + dot)
    cut_sketch(sh, body, sk, -0.35)
    # key icons — pixel bitmaps on a 0.45 mm grid (same 1-bit language as the firmware icons)
    ICONS = {
        'up':   [".......", "...X...", "..XXX..", ".XX.XX.", "XX...XX", "X.....X", "......."],
        'down': [".......", "X.....X", "XX...XX", ".XX.XX.", "..XXX..", "...X...", "......."],
        'menu': [".......", "XXXXXXX", ".......", "XXXXXXX", ".......", "XXXXXXX", "......."],
        'back': ["..X....", ".XX....", "XXXXXX.", ".XX...X", "..X...X", "......X", ".XXXXX."],
    }
    PX = 0.45
    sk = sh.sketches.add(plane(sh, Z_TOP))
    for c, kind in zip(KEY_Y, KEY_ICONS):
        bm = ICONS[kind]
        gx0, gy0 = ICON_X - len(bm[0]) * PX / 2, c + len(bm) * PX / 2
        for r, row in enumerate(bm):
            i = 0
            while i < len(row):
                if row[i] != 'X':
                    i += 1; continue
                i0 = i
                while i < len(row) and row[i] == 'X':
                    i += 1
                rect(sk, gx0 + i0 * PX, gy0 - (r + 1) * PX, gx0 + i * PX, gy0 - r * PX)
    cut_sketch(sh, body, sk, -0.3)
    # USB-C (right wall)
    box(sh, IN_X - 0.5, USB_Y - 5.0, USB_Z - 2.0, OUT_X + 0.5, USB_Y + 5.0, USB_Z + 2.0, CUT, body)
    box(sh, OUT_X - 1.0, USB_Y - 6.5, USB_Z - 3.0, OUT_X + 0.5, USB_Y + 6.5, USB_Z + 3.0, CUT, body)
    # corner screw bosses (merge into the walls), pilot holes for M2 from the back
    for (bx, by, br) in BOSSES:
        cyl(sh, bx, by, Z_BOT, Z_CAV + 0.01, br, JOIN, body)   # full height: fused to the front panel too
        # webs: fill from the boss to every wall it sits against, full boss width (no more line contact)
        if IN_X - abs(bx) < br + 0.3:
            wx = IN_X if bx > 0 else -IN_X
            box(sh, min(bx, wx) - (0.3 if bx < 0 else 0), by - br, Z_BOT, max(bx, wx) + (0.3 if bx > 0 else 0), by + br, Z_CAV + 0.01, JOIN, body)
        for wy in (IN_T, IN_B):
            if abs(wy - by) < br + 0.3:
                box(sh, bx - br, min(by, wy) - (0.3 if wy < by else 0), Z_BOT, bx + br, max(by, wy) + (0.3 if wy > by else 0), Z_CAV + 0.01, JOIN, body)
        cyl(sh, bx, by, Z_BOT - 0.01, Z_BOT + 5.5, PILOT_R, CUT, body)
    # groove in the top wall that takes the back cover's hook
    box(sh, HOOK[0] - 0.4, IN_T - 0.1, Z_BOT + 0.5, HOOK[1] + 0.4, IN_T + 0.9, Z_BOT + 1.7, CUT, body)
    # strap lugs on the top and bottom edges
    edges_y = {1: OUT_T, -1: OUT_B}
    for sx in (-1, 1):
        for sy in (-1, 1):
            e = edges_y[sy]
            xa, xb = sorted([sx * LUG_IN, sx * (LUG_IN + LUG_W)])
            ya, yb = sorted([e - sy * 1.0, e + sy * LUG_LEN])
            box(sh, xa, ya, Z_BOT, xb, yb, LUG_Z1, JOIN, body)
            ya, yb = sorted([e + sy * 0.2, e + sy * LUG_LEN])
            box(sh, xa, ya, LUG_Z0, xb, yb, Z_BOT + 0.01, JOIN, body)
    tips = [(sx * xx, edges_y[sy] + sy * LUG_LEN) for sx in (-1, 1) for sy in (-1, 1) for xx in (LUG_IN, LUG_IN + LUG_W)]
    fillet(sh, vedges(body, tips), 1.2)
    for sy in (-1, 1):
        e = edges_y[sy]
        sk = sh.sketches.add(sh.yZConstructionPlane)
        sk.sketchCurves.sketchCircles.addByCenterRadius(sk.modelToSketchSpace(P(0, e + sy * BAR_OFF, BAR_Z)), mm(BAR_D / 2))
        ei = sh.features.extrudeFeatures.createInput(sk.profiles.item(0), CUT)
        ei.setSymmetricExtent(V(LUG_IN + LUG_W + 1), False)  # distance per side
        ei.participantBodies = [body]
        sh.features.extrudeFeatures.add(ei)

    # =============== BACK COVER ===============
    bc = new_comp('PIXL Back v8')
    zb = Z_BOT - COVER_T
    cov = box(bc, -OUT_X, OUT_B, zb, OUT_X, OUT_T, Z_BOT, NEW)
    cov.name = 'Back'
    fillet(bc, vedges(cov, corners_out), R_OUT)
    fillet(bc, loop_edges(outer_loop(face_at_z(cov, zb))), 0.6)
    for (bx, by, br) in BOSSES:
        cyl(bc, bx, by, zb - 0.1, Z_BOT + 0.1, 1.1, CUT, cov)
        cyl(bc, bx, by, zb - 0.1, zb + 0.7, 1.95, CUT, cov)
    # alignment tab on the right wall
    box(bc, IN_X - 1.25, -0.5, Z_BOT - 0.01, IN_X - 0.25, 4.0, Z_BOT + 1.0, JOIN, cov)
    # hook on the top edge: an upright tab against the top wall with a lip that enters the groove
    box(bc, HOOK[0], IN_T - 1.1, Z_BOT - 0.01, HOOK[1], IN_T - 0.15, Z_BOT + 1.6, JOIN, cov)
    box(bc, HOOK[0], IN_T - 0.2, Z_BOT + 0.7, HOOK[1], IN_T + 0.65, Z_BOT + 1.45, JOIN, cov)
    # piezo seat: shallow pocket on the inside, the thinner back resonates
    cyl(bc, PIEZO[0], PIEZO[1], Z_BOT - 0.3, Z_BOT + 0.01, PIEZO[2] + 0.3, CUT, cov)
    # Mono You tone ramp on the outside
    T, TR, PITCH = 7.5, 2.2, 9.0   # kept clear of the side screw holes
    for k in range(4):
        tx, ty = (k - 1.5) * PITCH, (OUT_T + OUT_B) / 2
        sk = bc.sketches.add(plane(bc, zb))
        if k == 3:
            rrect(sk, tx, ty, T, T, TR); cut_sketch(bc, cov, sk, 0.3); continue
        rrect(sk, tx, ty, T, T, TR); rrect(sk, tx, ty, T - 1.2, T - 1.2, TR - 0.6)
        cut_sketch(bc, cov, sk, 0.3, lambda p: p.profileLoops.count == 2)
        if k == 0:
            continue
        sk = bc.sketches.add(plane(bc, zb))
        half = (T - 1.2) / 2 - 0.5
        csz, step = (0.8, 1.6) if k == 1 else (0.6, 0.85)
        nc = int((2 * half - csz) / step) + 1
        off = (2 * half - csz - (nc - 1) * step) / 2
        for j in range(nc):
            for i in range(nc):
                if k == 2 and (i + j) % 2:
                    continue
                x = tx - half + off + i * step; y = ty - half + off + j * step
                if abs(x + csz / 2 - tx) > half - 0.7 and abs(y + csz / 2 - ty) > half - 0.7:
                    continue
                rect(sk, x, y, x + csz, y + csz)
        cut_sketch(bc, cov, sk, 0.3)

    # =============== INTERNALS (reference) ===============
    it = new_comp('Internals v8 (reference)')
    b = box(it, BAT[0], BAT[1], Z_BOT + 0.7, BAT[2], BAT[3], Z_BOT + 5.7, NEW); b.name = 'LiPo 30x20x5'
    b = cyl(it, VIB[0], VIB[1], Z_BOT, Z_BOT + 2.7, VIB[2], NEW); b.name = 'Vibration motor 10x2.7'
    b = box(it, XIAO[0], XIAO[1], -1.3, XIAO[2], XIAO[3], -0.3, NEW); b.name = 'XIAO ESP32-S3 (upside down)'
    box(it, XIAO[2] - 7.0, USB_Y - 4.45, -4.5, XIAO[2] + 0.4, USB_Y + 4.45, -1.3, JOIN, b)
    box(it, XIAO[0] + 1.0, XIAO[1] + 1.0, -3.8, XIAO[2] - 7.0, XIAO[3] - 1.0, -1.3, JOIN, b)
    b = box(it, RTC[0], RTC[1], Z_BOT, RTC[2], RTC[3], Z_BOT + 6.2, NEW); b.name = 'DS3231 14x14 (no header)'
    b = cyl(it, PIEZO[0], PIEZO[1], Z_BOT - 0.3, Z_BOT + 0.2, PIEZO[2], NEW); b.name = 'Piezo disc 20mm'
    print('ok', round(2 * OUT_X, 1), 'x', round(OUT_T - OUT_B, 1), 'x', round(Z_TOP - zb, 1))
