// PIXL — hardware services used by the UI (implemented in PIXL_Firmware.ino)
#pragma once
#include <Arduino.h>

enum Key { K_UP = 0, K_DOWN = 1, K_HASH = 2, K_STAR = 3 };

void beep(uint16_t freq, uint16_t ms, float atSec = 0);  // piezo, queued
void vibrate(uint16_t ms, float atSec = 0);              // vibration motor, queued
float batteryLevel();                                    // 0..1, or -1 when not measured
bool sndOn();
void saveSettings();
void setRtcTime(time_t localEpoch);
void enterDeepOff();                                     // full power off (deep sleep, wake on keys / next alarm)
bool keyHeld(int k);
bool bleConnected();
