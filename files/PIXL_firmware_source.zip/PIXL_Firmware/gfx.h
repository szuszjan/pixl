// PIXL — 1-bit graphics core (port of the Mono You web kit).
// Framebuffer is stored in SSD1306 page format so it can be copied straight into U8g2's buffer.
#pragma once
#include <Arduino.h>
#include <math.h>
#include <string.h>

static const int SW = 128, SH = 64;
static const uint8_t BAYER[16] = {0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5};

static inline bool inRR(float px, float py, float x, float y, float w, float h, float r) {
  float cx = px + 0.5f, cy = py + 0.5f;
  if (cx < x || cy < y || cx > x + w || cy > y + h) return false;
  r = fminf(r, fminf(w / 2, h / 2));
  float qx = fmaxf(x + r, fminf(cx, x + w - r)), qy = fmaxf(y + r, fminf(cy, y + h - r));
  float dx = cx - qx, dy = cy - qy;
  return dx * dx + dy * dy <= r * r + 0.01f;
}

// ---------- 5x7 font, ASCII 32..90, column bytes (LSB = top). \x01 = Ś, \x02 = ° ----------
static const uint8_t F5[59][5] = {
  {0, 0, 0, 0, 0}, {0x00, 0x00, 0x5F, 0x00, 0x00}, {0}, {0}, {0}, {0x23, 0x13, 0x08, 0x64, 0x62}, {0}, {0}, {0}, {0}, {0},
  {0x08, 0x08, 0x3E, 0x08, 0x08}, {0x00, 0x50, 0x30, 0x00, 0x00}, {0x08, 0x08, 0x08, 0x08, 0x08}, {0x00, 0x60, 0x60, 0x00, 0x00}, {0x20, 0x10, 0x08, 0x04, 0x02},
  {0x3E, 0x51, 0x49, 0x45, 0x3E}, {0x00, 0x42, 0x7F, 0x40, 0x00}, {0x42, 0x61, 0x51, 0x49, 0x46}, {0x21, 0x41, 0x45, 0x4B, 0x31}, {0x18, 0x14, 0x12, 0x7F, 0x10},
  {0x27, 0x45, 0x45, 0x45, 0x39}, {0x3C, 0x4A, 0x49, 0x49, 0x30}, {0x01, 0x71, 0x09, 0x05, 0x03}, {0x36, 0x49, 0x49, 0x49, 0x36}, {0x06, 0x49, 0x49, 0x29, 0x1E},
  {0x00, 0x36, 0x36, 0x00, 0x00}, {0}, {0x08, 0x14, 0x22, 0x41, 0x00}, {0x14, 0x14, 0x14, 0x14, 0x14}, {0x00, 0x41, 0x22, 0x14, 0x08}, {0x02, 0x01, 0x51, 0x09, 0x06}, {0},
  {0x7E, 0x11, 0x11, 0x11, 0x7E}, {0x7F, 0x49, 0x49, 0x49, 0x36}, {0x3E, 0x41, 0x41, 0x41, 0x22}, {0x7F, 0x41, 0x41, 0x22, 0x1C}, {0x7F, 0x49, 0x49, 0x49, 0x41},
  {0x7F, 0x09, 0x09, 0x09, 0x01}, {0x3E, 0x41, 0x49, 0x49, 0x7A}, {0x7F, 0x08, 0x08, 0x08, 0x7F}, {0x00, 0x41, 0x7F, 0x41, 0x00}, {0x20, 0x40, 0x41, 0x3F, 0x01},
  {0x7F, 0x08, 0x14, 0x22, 0x41}, {0x7F, 0x40, 0x40, 0x40, 0x40}, {0x7F, 0x02, 0x0C, 0x02, 0x7F}, {0x7F, 0x04, 0x08, 0x10, 0x7F}, {0x3E, 0x41, 0x41, 0x41, 0x3E},
  {0x7F, 0x09, 0x09, 0x09, 0x06}, {0x3E, 0x41, 0x51, 0x21, 0x5E}, {0x7F, 0x09, 0x19, 0x29, 0x46}, {0x46, 0x49, 0x49, 0x49, 0x31}, {0x01, 0x01, 0x7F, 0x01, 0x01},
  {0x3F, 0x40, 0x40, 0x40, 0x3F}, {0x1F, 0x20, 0x40, 0x20, 0x1F}, {0x3F, 0x40, 0x38, 0x40, 0x3F}, {0x63, 0x14, 0x08, 0x14, 0x63}, {0x07, 0x08, 0x70, 0x08, 0x07},
  {0x61, 0x51, 0x49, 0x45, 0x43}};
static const uint8_t F5_SACUTE[5] = {0x44, 0x4A, 0x4A, 0x4B, 0x30};
static const uint8_t F5_DEG[5] = {0x00, 0x06, 0x09, 0x09, 0x06};

static const uint8_t *glyph5(char ch) {
  if (ch == 1) return F5_SACUTE;
  if (ch == 2) return F5_DEG;
  if (ch >= 'a' && ch <= 'z') ch -= 32;
  if (ch < 32 || ch > 90) return F5['?' - 32];
  const uint8_t *g = F5[ch - 32];
  if (ch != ' ' && !(g[0] | g[1] | g[2] | g[3] | g[4])) return F5['?' - 32];
  return g;
}
static inline int textW(const char *s, int sc = 1) { int n = strlen(s); return n ? n * 6 * sc - sc : 0; }

// ---------- 8x8 icons (rows, MSB = left) ----------
static const uint8_t IC_HEART[8] = {0x00, 0x66, 0xFF, 0xFF, 0xFF, 0x7E, 0x3C, 0x18};
static const uint8_t IC_BELL[8] = {0x18, 0x3C, 0x7E, 0x7E, 0x7E, 0xFF, 0x00, 0x18};
static const uint8_t IC_BT[8] = {0x10, 0x18, 0x54, 0x38, 0x38, 0x54, 0x18, 0x10};
static const uint8_t IC_MOON[8] = {0x3C, 0x70, 0xE0, 0xE0, 0xE0, 0xF1, 0x7E, 0x3C};
static const uint8_t IC_SUN[8] = {0x10, 0x82, 0x38, 0xBA, 0x38, 0x82, 0x10, 0x00};
static const uint8_t IC_CHECK[8] = {0x00, 0x01, 0x03, 0x86, 0xCC, 0x78, 0x30, 0x00};
static const uint8_t IC_STOPWATCH[8] = {0x38, 0x10, 0x7C, 0x92, 0x9A, 0x82, 0x44, 0x38};
static const uint8_t IC_HOURGLASS[8] = {0xFE, 0x82, 0x44, 0x38, 0x10, 0x38, 0x7C, 0xFE};
static const uint8_t IC_FLASH[8] = {0xFE, 0xFE, 0x7C, 0x38, 0x38, 0x28, 0x38, 0x38};
static const uint8_t IC_GEAR[8] = {0x18, 0x5A, 0x3C, 0xE7, 0xE7, 0x3C, 0x5A, 0x18};
static const uint8_t IC_CAL[8] = {0x44, 0xFE, 0xFE, 0x82, 0xAA, 0x82, 0xFE, 0x00};
static const uint8_t IC_METRO[8] = {0x10, 0x12, 0x34, 0x28, 0x48, 0x44, 0xFE, 0x00};
static const uint8_t IC_WIND[8] = {0x0C, 0x02, 0xFC, 0x00, 0xF0, 0x08, 0x30, 0x00};
static const uint8_t IC_DICE[8] = {0xFE, 0x82, 0xA2, 0x92, 0x8A, 0x82, 0xFE, 0x00};
static const uint8_t IC_SHIP[8] = {0x00, 0xC0, 0xF0, 0xFF, 0xF0, 0xC0, 0x00, 0x00};
static const uint8_t IC_GLIDER[8] = {0x00, 0x30, 0x30, 0x0C, 0x0C, 0xFC, 0xFC, 0x00};
static const uint8_t IC_FACE[8] = {0x38, 0x44, 0x92, 0x9A, 0x82, 0x44, 0x38, 0x00};
static const uint8_t IC_CONTRAST[8] = {0x3C, 0x4E, 0x8F, 0x8F, 0x8F, 0x8F, 0x4E, 0x3C};
static const uint8_t IC_INVERT[8] = {0xFE, 0x8E, 0x8E, 0x8E, 0x8E, 0x8E, 0xFE, 0x00};
static const uint8_t IC_SPEAKER[8] = {0x10, 0x32, 0xF1, 0xF5, 0xF5, 0xF1, 0x32, 0x10};
static const uint8_t IC_INFO[8] = {0x38, 0x54, 0xFE, 0xEE, 0xEE, 0xEE, 0x7C, 0x38};
static const uint8_t IC_POWER[8] = {0x10, 0x54, 0x92, 0x92, 0x82, 0x44, 0x38, 0x00};
static const uint8_t IC_VIBRO[8] = {0x3C, 0xA5, 0xA5, 0xA5, 0xA5, 0xA5, 0x3C, 0x00};

// ---------- framebuffer ----------
struct FB {
  uint8_t b[SW * SH / 8];
  void clear() { memset(b, 0, sizeof(b)); }
  inline uint8_t get(int x, int y) const { if ((unsigned)x >= (unsigned)SW || (unsigned)y >= (unsigned)SH) return 0; return (b[(y >> 3) * SW + x] >> (y & 7)) & 1; }
  inline void put(int x, int y, uint8_t v) {
    if ((unsigned)x >= (unsigned)SW || (unsigned)y >= (unsigned)SH) return;
    uint8_t m = 1 << (y & 7); uint8_t &B = b[(y >> 3) * SW + x];
    if (v) B |= m; else B &= ~m;
  }
  // c: 1 lit, 0 off, 2 XOR, 0<c<1 Bayer tone (only lights pixels)
  void px(float fx, float fy, float c = 1) {
    int x = (int)floorf(fx), y = (int)floorf(fy);
    if ((unsigned)x >= (unsigned)SW || (unsigned)y >= (unsigned)SH) return;
    uint8_t m = 1 << (y & 7); uint8_t &B = b[(y >> 3) * SW + x];
    if (c == 2) { B ^= m; return; }
    if (c > 0 && c < 1) { if (BAYER[((y & 3) << 2) | (x & 3)] < (int)lroundf(c * 16)) B |= m; return; }
    if (c != 0) B |= m; else B &= ~m;
  }
  void fill(int x, int y, int w, int h, float c = 1) { for (int j = y; j < y + h; j++) for (int i = x; i < x + w; i++) px(i, j, c); }
  void hline(int x, int y, int w, float c = 1) { fill(x, y, w, 1, c); }
  void vline(int x, int y, int h, float c = 1) { fill(x, y, 1, h, c); }
  void rrect(float x, float y, float w, float h, float r, float c = 1, bool f = true, float t = 1) {
    for (float j = y; j < y + h; j++) for (float i = x; i < x + w; i++) {
      if (!inRR(i, j, x, y, w, h, r)) continue;
      if (f || !inRR(i, j, x + t, y + t, w - 2 * t, h - 2 * t, fmaxf(0, r - t))) px(i, j, c);
    }
  }
  void disc(float cx, float cy, float r, float c = 1) {
    for (int j = (int)floorf(cy - r - 1); j <= cy + r + 1; j++) for (int i = (int)floorf(cx - r - 1); i <= cx + r + 1; i++) {
      float dx = i + 0.5f - cx, dy = j + 0.5f - cy;
      if (dx * dx + dy * dy <= r * r) px(i, j, c);
    }
  }
  void arc(float cx, float cy, float r, float t, float a0, float a1, float c = 1) {
    float R = r + 1;
    for (int j = (int)floorf(cy - R); j <= cy + R; j++) for (int i = (int)floorf(cx - R); i <= cx + R; i++) {
      float dx = i + 0.5f - cx, dy = j + 0.5f - cy, d = sqrtf(dx * dx + dy * dy);
      if (d > r || d < r - t) continue;
      float a = atan2f(dx, -dy) * 180.f / PI; if (a < 0) a += 360;
      if (a >= a0 && a <= a1) px(i, j, c);
    }
  }
  void ring(float cx, float cy, float r, float t, float c = 1) { arc(cx, cy, r, t, 0, 360, c); }
  void arcRound(float cx, float cy, float r, float t, float a0, float a1, float c = 1) {
    arc(cx, cy, r, t, a0, a1, c);
    float m = r - t / 2;
    float q0 = a0 * PI / 180, q1 = a1 * PI / 180;
    disc(cx + sinf(q0) * m, cy - cosf(q0) * m, t / 2, c);
    disc(cx + sinf(q1) * m, cy - cosf(q1) * m, t / 2, c);
  }
  void text(const char *s, int x, int y, float c = 1, int sc = 1) {
    for (; *s; s++) {
      const uint8_t *g = glyph5(*s);
      for (int cx = 0; cx < 5; cx++) for (int cy = 0; cy < 7; cy++) if ((g[cx] >> cy) & 1) fill(x + cx * sc, y + cy * sc, sc, sc, c);
      x += 6 * sc;
    }
  }
  void textHalo(const char *s, int x, int y, int sc = 1) {
    for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) if (dx || dy) text(s, x + dx, y + dy, 0, sc);
    text(s, x, y, 1, sc);
  }
  void icon(const uint8_t *rows, int x, int y, float c = 1, int sc = 1) {
    for (int ry = 0; ry < 8; ry++) for (int rx = 0; rx < 8; rx++) if ((rows[ry] >> (7 - rx)) & 1) fill(x + rx * sc, y + ry * sc, sc, sc, c);
  }
  void iconHalo(const uint8_t *rows, int x, int y, int sc = 1) {
    for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) if (dx || dy) icon(rows, x + dx, y + dy, 0, sc);
    icon(rows, x, y, 1, sc);
  }
  void invert() { for (auto &v : b) v = ~v; }
  // OR another buffer in, shifted
  void blitFrom(const uint8_t *src, int dx, int dy) {
    for (int y = 0; y < SH; y++) { int ny = y + dy; if (ny < 0 || ny >= SH) continue;
      for (int x = 0; x < SW; x++) { int nx = x + dx; if (nx < 0 || nx >= SW) continue;
        if ((src[(y >> 3) * SW + x] >> (y & 7)) & 1) put(nx, ny, 1); } }
  }
};
static inline uint8_t bufGet(const uint8_t *b, int x, int y) { return (b[(y >> 3) * SW + x] >> (y & 7)) & 1; }

// ---------- rounded clock digits: capsule strokes in a 1 x 1.6 box ----------
struct Pt { float x, y; };
struct Poly { uint8_t n; Pt p[64]; };
struct DigitDef { uint8_t n; Poly poly[3]; };
static DigitDef DIG[10];

static void addArc(Poly &pl, float cx, float cy, float r, float a0, float a1) {
  int n = max(4, (int)ceilf(fabsf(a1 - a0) / 8));
  for (int k = 0; k <= n && pl.n < 64; k++) { float a = (a0 + (a1 - a0) * k / n) * PI / 180; pl.p[pl.n++] = {cx + cosf(a) * r, cy + sinf(a) * r}; }
}
static void addPt(Poly &pl, float x, float y) { if (pl.n < 64) pl.p[pl.n++] = {x, y}; }
static void initDigits() {
  memset(DIG, 0, sizeof(DIG));
  Poly *p;
  p = &DIG[0].poly[0]; DIG[0].n = 1; addArc(*p, .5, .5, .5, 180, 360); addArc(*p, .5, 1.1, .5, 0, 180); addPt(*p, 0, .5);
  p = &DIG[1].poly[0]; DIG[1].n = 1; addPt(*p, .18, .3); addPt(*p, .56, 0); addPt(*p, .56, 1.6);
  p = &DIG[2].poly[0]; DIG[2].n = 1; addArc(*p, .5, .5, .5, 190, 380); addPt(*p, 0, 1.6); addPt(*p, 1, 1.6);
  DIG[3].n = 3; addArc(DIG[3].poly[0], .5, .4, .4, 200, 450); addArc(DIG[3].poly[1], .5, 1.2, .4, 270, 520); addPt(DIG[3].poly[2], .3, .8); addPt(DIG[3].poly[2], .5, .8);
  p = &DIG[4].poly[0]; DIG[4].n = 1; addPt(*p, .78, 1.6); addPt(*p, .78, 0); addPt(*p, 0, 1.12); addPt(*p, 1, 1.12);
  p = &DIG[5].poly[0]; DIG[5].n = 1; addPt(*p, .92, 0); addPt(*p, .14, 0); addPt(*p, .08, .78); addArc(*p, .5, 1.12, .48, 215, 500);
  DIG[6].n = 2; addArc(DIG[6].poly[0], .5, 1.12, .48, 0, 360); addPt(DIG[6].poly[1], .04, 1.04); addPt(DIG[6].poly[1], .6, 0);
  p = &DIG[7].poly[0]; DIG[7].n = 1; addPt(*p, 0, 0); addPt(*p, 1, 0); addPt(*p, .36, 1.6);
  DIG[8].n = 2; addArc(DIG[8].poly[0], .5, .38, .38, 0, 360); addArc(DIG[8].poly[1], .5, 1.17, .43, 0, 360);
  DIG[9].n = 2; addArc(DIG[9].poly[0], .5, .48, .48, 0, 360); addPt(DIG[9].poly[1], .96, .56); addPt(DIG[9].poly[1], .4, 1.6);
}
static inline float segDist(float px, float py, float ax, float ay, float bx, float by) {
  float vx = bx - ax, vy = by - ay, wx = px - ax, wy = py - ay, l = vx * vx + vy * vy;
  float t = l > 0 ? fmaxf(0, fminf(1, (wx * vx + wy * vy) / l)) : 0, dx = wx - t * vx, dy = wy - t * vy;
  return sqrtf(dx * dx + dy * dy);
}

enum { ST_SOLID = 0, ST_OUTLINE = 1, ST_TONAL = 2 };
// glyph cache: rendering a digit is a few thousand distance tests, so each (digit,size,style) is drawn once
struct GCache { char ch; uint8_t u, style; float r, lw; uint8_t w, h; uint32_t used; uint8_t *data; };
static GCache gcache[28];
static uint32_t gtick = 0;
static GCache *glyphGet(char ch, float u, float r, float lw, uint8_t style) {
  for (auto &g : gcache) if (g.data && g.ch == ch && g.u == (uint8_t)u && g.r == r && g.lw == lw && g.style == style) { g.used = ++gtick; return &g; }
  GCache *slot = &gcache[0];
  for (auto &g : gcache) { if (!g.data) { slot = &g; break; } if (g.used < slot->used) slot = &g; }
  int Wg = (int)ceilf(u + 2 * r), Hg = (int)ceilf(1.6f * u + 2 * r);
  if (slot->data) free(slot->data);
  slot->data = (uint8_t *)calloc(Wg * Hg, 1);
  slot->ch = ch; slot->u = (uint8_t)u; slot->r = r; slot->lw = lw; slot->style = style; slot->w = Wg; slot->h = Hg; slot->used = ++gtick;
  const DigitDef &D = DIG[ch - '0'];
  for (int j = 0; j < Hg; j++) for (int i = 0; i < Wg; i++) {
    float d = 1e9, cx = i + 0.5f, cy = j + 0.5f;
    for (int q = 0; q < D.n; q++) { const Poly &pl = D.poly[q];
      for (int k = 0; k + 1 < pl.n; k++) {
        float dd = segDist(cx, cy, r + pl.p[k].x * u, r + pl.p[k].y * u, r + pl.p[k + 1].x * u, r + pl.p[k + 1].y * u);
        if (dd < d) d = dd;
      } }
    if (d > r) continue;
    uint8_t v = 1;
    if (style != ST_SOLID && d <= r - lw) v = style == ST_TONAL ? 3 : 2;
    slot->data[j * Wg + i] = v;
  }
  return slot;
}
// clipY0/clipY1 limit the rows (used by the rolling digits)
static int glyph(FB &fb, char ch, int x, int y, float u, float r, float lw, uint8_t style, int dy = 0, int clipY0 = -999, int clipY1 = 999) {
  if (ch < '0' || ch > '9') return 0;
  GCache *g = glyphGet(ch, u, r, lw, style);
  for (int j = 0; j < g->h; j++) { int yy = y + dy + j; if (yy < clipY0 || yy >= clipY1) continue;
    for (int i = 0; i < g->w; i++) { uint8_t v = g->data[j * g->w + i]; if (!v) continue; int xx = x + i;
      if (v == 1) fb.put(xx, yy, 1);
      else { fb.put(xx, yy, 0); if (v == 3 && ((unsigned)xx < 128) && BAYER[((yy & 3) << 2) | (xx & 3)] < 8) fb.put(xx, yy, 1); } } }
  return g->w;
}
struct TLayout { int W, H, cw, g, w; };
static TLayout timeLayout(const char *str, float u, float r, int gap = 3) {
  TLayout L; L.W = (int)ceilf(u + 2 * r); L.cw = (int)ceilf(2 * r + 2); L.g = gap; L.H = (int)ceilf(1.6f * u + 2 * r); L.w = 0;
  for (int k = 0; str[k]; k++) L.w += (str[k] == ':' ? L.cw : L.W) + (k ? L.g : 0);
  return L;
}
