// PIXL watch firmware 2.3 — Seeed XIAO ESP32-S3 + 0.96" 128x64 OLED module with 4 keys (^ v menu back — silkscreen ^ v # *),
// DS3231 RTC, passive buzzer, vibration motor, 250 mAh Li-Po. Design: Mono You (1-bit Material You).
// Board: esp32:esp32:XIAO_ESP32S3   Libraries: U8g2, NimBLE-Arduino 2.x
//
// Wiring (see README.md):
//   OLED + DS3231: SDA D4, SCL D5, VCC 3V3, GND
//   Keys (to GND, internal pull-ups): ^ D9, v D7, # D2, * D3 (D1 and D6 free)
//   Buzzer D8 (PWM), vibration motor D0 via NPN (S9014, 330R base) + flyback diode, battery divider (33k/33k) -> D10

#include <Arduino.h>
#include <Wire.h>
#include <U8g2lib.h>
#include <Preferences.h>
#include <NimBLEDevice.h>
#include "driver/rtc_io.h"
#include "esp_sleep.h"
#include "hw.h"
#include "apps.h"

// ---------- configuration ----------
#define OLED_SH1106 0           // 1 if your 0.96" module turns out to be SH1106 (picture shifted by 2 px)
#define KEYS_ACTIVE_LOW 1       // keys short to GND
#define I2C_HZ 800000           // SSD1306 is fine at 800 kHz; drop to 400000 if the image glitches
static const uint8_t PIN_KEY[4] = {D9, D7, D2, D3};  // up, down, menu (#), back (*)
#define PIN_BUZZ D8
#define PIN_VIB D0
#define PIN_BAT D10
// battery divider: BAT+ -- R_TOP -- D10 -- R_BOT -- GND (any values 47k..470k; keep R_BOT >= R_TOP/3 so D10 stays under ~3 V)
#define BAT_R_TOP 33.0f   // salvaged 33k (orange-orange-orange)
#define BAT_R_BOT 33.0f
#define FW_VERSION "2.3"

#if OLED_SH1106
U8G2_SH1106_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);
#else
U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);
#endif
Preferences prefs;

// ---------- DS3231 ----------
static bool rtcOK = false;
static uint8_t bcd2bin(uint8_t v) { return (v >> 4) * 10 + (v & 15); }
static uint8_t bin2bcd(int v) { return ((v / 10) << 4) | (v % 10); }
static bool rtcRead(struct tm &t) {
  Wire.beginTransmission(0x68); Wire.write(0); if (Wire.endTransmission() != 0) return false;
  if (Wire.requestFrom((uint8_t)0x68, (size_t)7) != 7) return false;
  uint8_t r[7]; for (int i = 0; i < 7; i++) r[i] = Wire.read();
  memset(&t, 0, sizeof(t));
  t.tm_sec = bcd2bin(r[0] & 0x7F); t.tm_min = bcd2bin(r[1] & 0x7F); t.tm_hour = bcd2bin(r[2] & 0x3F);
  t.tm_mday = bcd2bin(r[4] & 0x3F); t.tm_mon = bcd2bin(r[5] & 0x1F) - 1; t.tm_year = bcd2bin(r[6]) + 100;
  return true;
}
static bool rtcLostPower() {
  Wire.beginTransmission(0x68); Wire.write(0x0F); if (Wire.endTransmission() != 0) return true;
  if (Wire.requestFrom((uint8_t)0x68, (size_t)1) != 1) return true;
  return Wire.read() & 0x80;
}
static void rtcWrite(const struct tm &t) {
  Wire.beginTransmission(0x68); Wire.write(0);
  Wire.write(bin2bcd(t.tm_sec)); Wire.write(bin2bcd(t.tm_min)); Wire.write(bin2bcd(t.tm_hour));
  Wire.write(bin2bcd(t.tm_wday + 1)); Wire.write(bin2bcd(t.tm_mday)); Wire.write(bin2bcd(t.tm_mon + 1)); Wire.write(bin2bcd(t.tm_year - 100));
  Wire.endTransmission();
  Wire.beginTransmission(0x68); Wire.write(0x0F); Wire.write(0x00); Wire.endTransmission();  // clear OSF
}
void setRtcTime(time_t localEpoch) {
  struct timeval tv = {localEpoch, 0}; settimeofday(&tv, nullptr);
  struct tm t; gmtime_r(&localEpoch, &t); if (rtcOK) rtcWrite(t);
}
static void timeFromCompile(struct tm &t) {  // __DATE__ "Nov  6 2026", __TIME__ "18:40:12"
  static const char *m = "JanFebMarAprMayJunJulAugSepOctNovDec"; char mon[4] = {__DATE__[0], __DATE__[1], __DATE__[2], 0};
  memset(&t, 0, sizeof(t)); t.tm_mon = (strstr(m, mon) - m) / 3; t.tm_mday = atoi(__DATE__ + 4); t.tm_year = atoi(__DATE__ + 7) - 1900;
  t.tm_hour = atoi(__TIME__); t.tm_min = atoi(__TIME__ + 3); t.tm_sec = atoi(__TIME__ + 6);
}
static void initClock() {
  setenv("TZ", "UTC0", 1); tzset();  // the RTC keeps local wall time; the phone sends local epoch
  struct tm t;
  rtcOK = rtcRead(t);
  bool valid = rtcOK && !rtcLostPower() && t.tm_year >= 124;
  if (!valid) { timeFromCompile(t); if (rtcOK) rtcWrite(t); }
  time_t e = mktime(&t); struct timeval tv = {e, 0}; settimeofday(&tv, nullptr);
}

// ---------- settings ----------
void saveSettings() {
  prefs.putUChar("face", SET.face); prefs.putUChar("con", SET.contrast); prefs.putUChar("slp", SET.sleep);
  prefs.putBool("aod", SET.aod); prefs.putBool("inv", SET.invert); prefs.putBool("snd", SET.sound); prefs.putBool("vib", SET.vibro);
  prefs.putUChar("alH", S.alH); prefs.putUChar("alM", S.alM); prefs.putBool("alOn", S.alOn); prefs.putUShort("best", S.best);
}
static void loadSettings() {
  SET.face = prefs.getUChar("face", 0) % 4; SET.contrast = prefs.getUChar("con", 3) % 4; SET.sleep = prefs.getUChar("slp", 1) % 4;
  SET.aod = prefs.getBool("aod", true); SET.invert = prefs.getBool("inv", false); SET.sound = prefs.getBool("snd", true); SET.vibro = prefs.getBool("vib", true);
  S.alH = prefs.getUChar("alH", 7) % 24; S.alM = prefs.getUChar("alM", 0) % 60; S.alOn = prefs.getBool("alOn", true); S.best = prefs.getUShort("best", 0);
}
bool sndOn() { return SET.sound; }

// ---------- buzzer & vibration queue ----------
struct QE { uint32_t at; uint16_t f, ms; uint8_t vib; };
static QE q[48]; static int nq = 0; static uint32_t vibOff = 0;
void beep(uint16_t f, uint16_t ms, float atSec) { if (nq < 48) q[nq++] = {millis() + (uint32_t)(atSec * 1000), f, ms, 0}; }
void vibrate(uint16_t ms, float atSec) { if (SET.vibro && nq < 48) q[nq++] = {millis() + (uint32_t)(atSec * 1000), 0, ms, 1}; }
static void serviceQueue() {
  uint32_t now = millis();
  for (int i = 0; i < nq;) {
    if ((int32_t)(now - q[i].at) >= 0) {
      if (q[i].vib) { digitalWrite(PIN_VIB, HIGH); vibOff = now + q[i].ms; }
      else tone(PIN_BUZZ, q[i].f, q[i].ms);
      q[i] = q[--nq];
    } else i++;
  }
  if (vibOff && (int32_t)(now - vibOff) >= 0) { digitalWrite(PIN_VIB, LOW); vibOff = 0; }
}

// ---------- battery ----------
static float batV = -1; static uint32_t batT = 0;
float batteryLevel() {
  if (millis() - batT > 2000 || batT == 0) {
    batT = millis();
    float v = analogReadMilliVolts(PIN_BAT) * ((BAT_R_TOP + BAT_R_BOT) / BAT_R_BOT) / 1000.f;
    batV = v < 2.5f ? -1 : (batV < 0 ? v : batV * 0.8f + v * 0.2f);
  }
  if (batV < 0) return -1;
  return clampf((batV - 3.3f) / (4.15f - 3.3f), 0, 1);
}

// ---------- keys ----------
struct KeyState { bool down; uint32_t t0, chg; bool longDone, offDone; uint32_t nextRep; };
static KeyState ks[4];
bool keyHeld(int k) { return ks[k].down; }
static bool rawDown(int k) { bool v = digitalRead(PIN_KEY[k]); return KEYS_ACTIVE_LOW ? !v : v; }
static void press(int k, bool rep) {
  if (S.booting) return;
  S.lastInput = millis();
  bool quiet = (S.screen == SC_MENU || S.screen == SC_SET || S.screen == SC_FACE) && !AL.on && !S.asleep;
  if (!rep && SET.sound && !quiet) beep(3400, 6);
  if (AL.on) { if (!rep) alertKey(k); return; }
  if (S.asleep) { if (!rep) wakeScreen(); return; }
  keyScreen(k, rep);
}
static void pollKeys() {
  uint32_t now = millis();
  for (int k = 0; k < 4; k++) {
    KeyState &s = ks[k]; bool d = rawDown(k);
    if (d != s.down && now - s.chg > 15) {
      s.chg = now; s.down = d;
      if (d) {
        s.t0 = now; s.longDone = false; s.offDone = false; s.nextRep = now + 420;
        if (k != K_STAR) press(k, false);
      } else {
        if (k == K_STAR && !s.longDone && !S.booting) press(K_STAR, false);
      }
    }
    if (!s.down || S.booting) continue;
    if (k == K_STAR) {  // back: tap = back, hold 0.65 s = screen off, hold 3 s = power off
      if (!s.longDone && now - s.t0 > 650) { s.longDone = true; S.lastInput = now; if (!AL.on) sleepScreen(); }
      if (!s.offDone && now - s.t0 > 3000) { s.offDone = true; S.offPending = true; }
    } else if ((k == K_UP || k == K_DOWN) && (int32_t)(now - s.nextRep) >= 0) { s.nextRep = now + 110; press(k, true); }
  }
}

// ---------- deep "off" ----------
RTC_DATA_ATTR static bool rtcAlarmWake = false;
static time_t secondsToAlarm() {
  time_t now = time(nullptr); struct tm t; localtime_r(&now, &t);
  int cur = t.tm_hour * 3600 + t.tm_min * 60 + t.tm_sec, al = S.alH * 3600 + S.alM * 60;
  int d = al - cur; if (d <= 0) d += 86400; return d;
}
void enterDeepOff() {
  u8g2.setPowerSave(1);
  digitalWrite(PIN_VIB, LOW); noTone(PIN_BUZZ);
  uint64_t mask = 0;
  for (int k = 0; k < 4; k++) {  // every key on an RTC GPIO (0-21) can wake; v on D7 (GPIO44) can't
    gpio_num_t g = (gpio_num_t)PIN_KEY[k]; if (!rtc_gpio_is_valid_gpio(g)) continue; mask |= 1ULL << g;
    rtc_gpio_init(g); rtc_gpio_set_direction(g, RTC_GPIO_MODE_INPUT_ONLY); rtc_gpio_pullup_en(g); rtc_gpio_pulldown_dis(g);
  }
  esp_sleep_enable_ext1_wakeup(mask, ESP_EXT1_WAKEUP_ANY_LOW);
  rtcAlarmWake = false;
  if (S.alOn) { esp_sleep_enable_timer_wakeup((uint64_t)secondsToAlarm() * 1000000ULL); rtcAlarmWake = true; }
  esp_deep_sleep_start();
}
static void releaseRtcPins() { for (int k = 0; k < 4; k++) if (rtc_gpio_is_valid_gpio((gpio_num_t)PIN_KEY[k])) rtc_gpio_deinit((gpio_num_t)PIN_KEY[k]); }

// ---------- BLE (companion) ----------
#define SVC_UUID "8f1d0001-6a2b-4b4e-9c3a-5049584c0001"
#define CMD_UUID "8f1d0002-6a2b-4b4e-9c3a-5049584c0001"
#define STATE_UUID "8f1d0003-6a2b-4b4e-9c3a-5049584c0001"
static volatile bool bleConn = false;
static QueueHandle_t cmdQ;
static NimBLECharacteristic *stateChr = nullptr;
struct Cmd { char s[100]; };
bool bleConnected() { return bleConn; }
class SrvCB : public NimBLEServerCallbacks {
  void onConnect(NimBLEServer *, NimBLEConnInfo &) override { bleConn = true; }
  void onDisconnect(NimBLEServer *, NimBLEConnInfo &, int) override { bleConn = false; NimBLEDevice::startAdvertising(); }
};
class CmdCB : public NimBLECharacteristicCallbacks {
  void onWrite(NimBLECharacteristic *c, NimBLEConnInfo &) override {
    Cmd m; NimBLEAttValue v = c->getValue(); size_t n = min((size_t)99, (size_t)v.length());
    memcpy(m.s, v.data(), n); m.s[n] = 0; xQueueSend(cmdQ, &m, 0);
  }
};
static void initBLE() {
  cmdQ = xQueueCreate(8, sizeof(Cmd));
  NimBLEDevice::init("PIXL");
  NimBLEServer *srv = NimBLEDevice::createServer(); srv->setCallbacks(new SrvCB());
  NimBLEService *svc = srv->createService(SVC_UUID);
  NimBLECharacteristic *cmd = svc->createCharacteristic(CMD_UUID, NIMBLE_PROPERTY::WRITE | NIMBLE_PROPERTY::WRITE_NR);
  cmd->setCallbacks(new CmdCB());
  stateChr = svc->createCharacteristic(STATE_UUID, NIMBLE_PROPERTY::READ | NIMBLE_PROPERTY::NOTIFY);
  svc->start();
  NimBLEAdvertising *adv = NimBLEDevice::getAdvertising();
  adv->setName("PIXL"); adv->addServiceUUID(SVC_UUID); adv->enableScanResponse(true); adv->start();
}
// Commands (UTF-8 text, one per write):
//   T<epoch>          set local time (seconds, local wall clock)      M<text>  show a message
//   F                 find my watch                                   R<min>   start the timer
//   A<h>,<m>,<on>     set alarm                                       S<key>=<val>  face|aod|contrast|sleep|invert|sound|vibro
static void handleCmd(const char *c) {
  switch (c[0]) {
    case 'T': setRtcTime((time_t)atoll(c + 1)); break;
    case 'M': fireAlert(AK_NOTE, c + 1); if (SET.vibro) { vibrate(80); vibrate(80, 0.18f); } if (snd()) { beep(2700, 50); beep(2700, 50, 0.1f); } break;
    case 'F': fireAlert(AK_FIND); break;
    case 'R': { int m = constrain(atoi(c + 1), 1, 99); S.tmSet = m * 60; S.tmLeft = S.tmSet * 1000; S.tmStarted = S.tmRun = true; S.tmEnd = millis() + S.tmLeft; } break;
    case 'A': { int h = 0, m = 0, on = 1; sscanf(c + 1, "%d,%d,%d", &h, &m, &on); S.alH = constrain(h, 0, 23); S.alM = constrain(m, 0, 59); S.alOn = on; S.alSnooze = 0; saveSettings(); } break;
    case 'S': {
      char key[12] = {0}; int val = 0; if (sscanf(c + 1, "%11[^=]=%d", key, &val) != 2) break;
      if (!strcmp(key, "face")) SET.face = imod(val, 4); else if (!strcmp(key, "aod")) SET.aod = val; else if (!strcmp(key, "contrast")) SET.contrast = imod(val, 4);
      else if (!strcmp(key, "sleep")) SET.sleep = imod(val, 4); else if (!strcmp(key, "invert")) SET.invert = val; else if (!strcmp(key, "sound")) SET.sound = val; else if (!strcmp(key, "vibro")) SET.vibro = val;
      saveSettings();
    } break;
  }
  S.lastInput = millis();
}
static uint32_t stateT = 0;
static void bleService() {
  Cmd m; while (xQueueReceive(cmdQ, &m, 0) == pdTRUE) handleCmd(m.s);
  if (stateChr && millis() - stateT > 5000) {
    stateT = millis(); float b = batteryLevel(); char s[96];
    snprintf(s, sizeof(s), "bat=%d;face=%d;al=%02d:%02d,%d;fw=%s", b < 0 ? -1 : (int)roundf(b * 100), SET.face, S.alH, S.alM, S.alOn, FW_VERSION);
    stateChr->setValue((uint8_t *)s, strlen(s)); if (bleConn) stateChr->notify();
  }
}

// ---------- background services ----------
static void services() {
  uint32_t now = millis();
  if (S.tmRun && (int32_t)(now - S.tmEnd) >= 0) { S.tmRun = false; S.tmStarted = false; S.tmLeft = S.tmSet * 1000; S.tmDir = 1; fireAlert(AK_TIMER); }
  Now n = getNow();
  time_t tn = time(nullptr); struct tm tt; localtime_r(&tn, &tt);
  int stamp = tt.tm_yday * 1440 + n.h * 60 + n.m;
  if (!S.booting && S.alOn && S.alField < 0 && n.h == S.alH && n.m == S.alM && S.alLastFire != stamp) { S.alLastFire = stamp; fireAlert(AK_ALARM); }
  if (S.alSnooze && tn >= S.alSnooze) { S.alSnooze = 0; fireAlert(AK_ALARM); }
  int sl = SLEEP_S[SET.sleep];
  bool busy = S.screen == SC_FL || (S.screen == SC_MET && S.metRun) || (S.screen == SC_BR && S.brRun) || (S.screen == SC_GAME && GM.mode == GM_PLAY) || S.screen == SC_LIFE;
  if (!S.asleep && !AL.on && !S.booting && sl && !busy && now - S.lastInput > (uint32_t)sl * 1000) sleepScreen();
}

static bool offAnim = false;
static void pushDisplay() {
  static int lastContrast = -1; static bool lastSave = false;
  bool dark = S.asleep && !SET.aod && !PW.on && !AL.on;
  if (dark != lastSave) { u8g2.setPowerSave(dark); lastSave = dark; }
  int c = (S.asleep && !PW.on) ? 0x01 : CONTRAST_V[SET.contrast];
  if (c != lastContrast) { u8g2.setContrast(c); lastContrast = c; }
  if (!dark) { memcpy(u8g2.getBufferPtr(), disp.b, sizeof(disp.b)); u8g2.sendBuffer(); }
}

// ---------- setup / loop ----------
static bool holdToWake() {  // after a key wake-up, require ~0.9 s of holding any key
  for (int k = 0; k < 4; k++) pinMode(PIN_KEY[k], INPUT_PULLUP);
  uint32_t t0 = millis();
  while (millis() - t0 < 900) { bool any = false; for (int k = 0; k < 4; k++) any |= rawDown(k); if (!any) return false; delay(10); }
  return true;
}
void setup() {
  esp_sleep_wakeup_cause_t cause = esp_sleep_get_wakeup_cause();
  bool alarmWake = cause == ESP_SLEEP_WAKEUP_TIMER && rtcAlarmWake;
  if (cause == ESP_SLEEP_WAKEUP_EXT1 || cause == ESP_SLEEP_WAKEUP_TIMER) releaseRtcPins();
  prefs.begin("pixl", false); loadSettings();
  if (cause == ESP_SLEEP_WAKEUP_EXT1 && !holdToWake()) enterDeepOff();  // short tap while off: stay off

  for (int k = 0; k < 4; k++) pinMode(PIN_KEY[k], INPUT_PULLUP);
  pinMode(PIN_VIB, OUTPUT); digitalWrite(PIN_VIB, LOW);
  pinMode(PIN_BUZZ, OUTPUT);
  analogReadResolution(12);
  for (int k = 0; k < 4; k++) { ks[k].down = rawDown(k); ks[k].longDone = true; ks[k].offDone = true; }  // ignore the key used to wake

  Wire.begin(SDA, SCL); Wire.setClock(I2C_HZ);
  u8g2.setBusClock(I2C_HZ); u8g2.begin(); u8g2.setContrast(CONTRAST_V[SET.contrast]);
  initClock();
  initDigits(); initLogo();
  initBLE();

  if (alarmWake) { S.booting = false; S.screen = SC_FACE; fireAlert(AK_ALARM); S.alLastFire = -2; }
  else startBoot();
}

void loop() {
  uint32_t t0 = millis();
  pollKeys(); serviceQueue(); bleService(); alertService(); services();
  if ((S.offPending || S.restartPending) && !offAnim) {
    offAnim = true; AL.on = false; S.booting = false; TR.on = false;
    memcpy(PW.src, disp.b, sizeof(PW.src)); PW.on = true; PW.off = true; PW.t0 = millis();
    if (snd()) { static const uint16_t f[] = {1047, 784, 523, 262}; for (int i = 0; i < 4; i++) beep(f[i], 80, i * 0.08f); }
  }
  composeFrame();
  if (offAnim && !PW.on) {
    disp.clear(); pushDisplay(); delay(400);
    if (S.restartPending) ESP.restart(); else enterDeepOff();
  }
  pushDisplay();
  uint32_t frame = (S.asleep && !PW.on && !AL.on) ? 250 : 33;
  uint32_t el = millis() - t0; if (el < frame) delay(frame - el);
}
