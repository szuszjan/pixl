// PIXL — UI building blocks (Mono You components, ported from the web prototype)
#pragma once
#include "gfx.h"
#include "hw.h"

static inline float clampf(float v, float a, float b) { return fmaxf(a, fminf(b, v)); }
static inline float lerpf(float a, float b, float t) { return a + (b - a) * t; }
static inline int imod(int a, int n) { return ((a % n) + n) % n; }
static inline float easeOut(float p) { return 1 - powf(1 - p, 3); }
static inline float easeIn(float p) { return p * p * p; }
static inline float easeInOut(float p) { return p < 0.5f ? 4 * p * p * p : 1 - powf(-2 * p + 2, 3) / 2; }
static inline float easeBack(float p) { float c1 = 1.9f, c3 = c1 + 1; return 1 + c3 * powf(p - 1, 3) + c1 * powf(p - 1, 2); }

static void center(FB &fb, const char *s, int y, float c = 1, int sc = 1) { fb.text(s, (SW - textW(s, sc)) / 2, y, c, sc); }
static void rightText(FB &fb, const char *s, int y, float c = 1) { fb.text(s, SW - 2 - textW(s), y, c); }
static void line(FB &fb, float x0, float y0, float x1, float y1, float c = 1) {
  int n = (int)fmaxf(fabsf(x1 - x0), fabsf(y1 - y0)); if (n < 1) n = 1;
  for (int i = 0; i <= n; i++) fb.px(roundf(x0 + (x1 - x0) * i / n), roundf(y0 + (y1 - y0) * i / n), c);
}
static void capsule(FB &fb, float x0, float y0, float x1, float y1, float r, float c = 1) {
  int n = (int)ceilf(hypotf(x1 - x0, y1 - y0) * 2); if (n < 1) n = 1;
  for (int i = 0; i <= n; i++) fb.disc(lerpf(x0, x1, (float)i / n), lerpf(y0, y1, (float)i / n), r, c);
}
static void pillLabel(FB &fb, const char *s, int y) {
  int w = textW(s) + 12, x = (SW - w) / 2;
  fb.rrect(x - 1, y - 1, w + 2, 13, 6.5, 0, true); fb.rrect(x, y, w, 11, 5.5, 1, false); fb.text(s, x + 6, y + 2, 1);
}
static void pad2(char *o, int n) { o[0] = '0' + (n / 10) % 10; o[1] = '0' + n % 10; o[2] = 0; }
static void fmtHM(char *o, int a, int b) { pad2(o, a); o[2] = ':'; pad2(o + 3, b); }

// 3x5 micro font (calendar)
static const uint8_t T3D[10][5] = {{7, 5, 5, 5, 7}, {2, 6, 2, 2, 7}, {7, 1, 7, 4, 7}, {7, 1, 7, 1, 7}, {5, 5, 7, 1, 1}, {7, 4, 7, 1, 7}, {7, 4, 7, 5, 7}, {7, 1, 1, 2, 2}, {7, 5, 7, 5, 7}, {7, 5, 7, 1, 7}};
static const uint8_t T3P[5] = {6, 5, 6, 4, 4}, T3W[5] = {5, 5, 5, 7, 5}, T3S[5] = {3, 4, 2, 1, 6}, T3C[5] = {3, 4, 4, 4, 3}, T3N[5] = {5, 7, 7, 5, 5};
static void tiny(FB &fb, const char *s, int x, int y) {
  for (; *s; s++, x += 4) {
    const uint8_t *g = nullptr;
    if (*s >= '0' && *s <= '9') g = T3D[*s - '0']; else if (*s == 'P') g = T3P; else if (*s == 'W') g = T3W; else if (*s == 'S') g = T3S; else if (*s == 'C') g = T3C; else if (*s == 'N') g = T3N;
    if (g) for (int r = 0; r < 5; r++) for (int b = 0; b < 3; b++) if ((g[r] >> (2 - b)) & 1) fb.px(x + b, y + r, 1);
  }
}

// key glyphs: up, down, menu (the module's # key), back (the module's * key)
static const uint8_t KG[4][5] = {{0x30, 0x18, 0x0C, 0x18, 0x30}, {0x06, 0x0C, 0x18, 0x0C, 0x06}, {0x2A, 0x2A, 0x2A, 0x2A, 0x2A}, {0x04, 0x2E, 0x24, 0x24, 0x18}};
static void kglyph(FB &fb, int k, int x, int y, float c) { for (int cx = 0; cx < 5; cx++) for (int cy = 0; cy < 7; cy++) if ((KG[k][cx] >> cy) & 1) fb.px(x + cx, y + cy, c); }
struct Hint { int8_t k; const char *label; bool filled; };
static int hintW(const char *l) { return 4 + 5 + (l && *l ? 3 + textW(l) : 0) + 4; }
static int hint(FB &fb, int x, int y, const Hint &h, bool inv) {
  int w = hintW(h.label); float fg = inv ? 0 : 1, bg = 1 - fg;
  fb.rrect(x, y, w, 11, 5.5, bg, true);
  if (h.filled) fb.rrect(x, y, w, 11, 5.5, fg, true); else fb.rrect(x, y, w, 11, 5.5, fg, false);
  float c = h.filled ? bg : fg;
  kglyph(fb, h.k, x + 4, y + 2, c); if (h.label && *h.label) fb.text(h.label, x + 12, y + 2, c);
  return w;
}
static void hints(FB &fb, const Hint *list, int n, bool inv = false, int y = 53) {
  int total = 3 * (n - 1); for (int i = 0; i < n; i++) total += hintW(list[i].label);
  int x = (SW - total) / 2; for (int i = 0; i < n; i++) x += hint(fb, x, y, list[i], inv) + 3;
}

// components
static void battery(FB &fb, int x, int y, float lvl) {
  fb.rrect(x, y, 12, 7, 2, 1, false); fb.fill(x + 12, y + 2, 1, 3, 1);
  if (lvl < 0) { fb.fill(x + 2, y + 2, 8, 3, 0.5); return; }
  fb.fill(x + 2, y + 2, max(1, (int)roundf(8 * lvl)), 3, 1);
}
enum { CHIP_FILLED, CHIP_OUTLINED, CHIP_TONAL };
static int chip(FB &fb, int x, int y, const char *label, int v, const uint8_t *ic = nullptr) {
  int w = (ic ? 14 : 5) + textW(label) + 5, h = 11; float r = 5.5;
  fb.rrect(x, y, w, h, r, 0, true);
  if (v == CHIP_FILLED) fb.rrect(x, y, w, h, r, 1, true);
  else if (v == CHIP_TONAL) { fb.rrect(x + 1, y + 1, w - 2, h - 2, r - 1, 0.25, true); fb.rrect(x, y, w, h, r, 1, false); }
  else fb.rrect(x, y, w, h, r, 1, false);
  int tx = x + (ic ? 14 : 5); float tc = v == CHIP_FILLED ? 0 : 1;
  if (ic) { if (v == CHIP_TONAL) fb.iconHalo(ic, x + 4, y + 1); else fb.icon(ic, x + 4, y + 1, tc); }
  if (v == CHIP_TONAL) fb.textHalo(label, tx, y + 2); else fb.text(label, tx, y + 2, tc);
  return w;
}
static void progressBar(FB &fb, int x, int y, int w, float v) {
  v = clampf(v, 0, 1); int a = (int)roundf((w - 6) * v);
  if (a > 0) fb.rrect(x, y, a, 4, 2, 1, true);
  int tx = x + a + (a > 0 ? 3 : 0), tw2 = x + w - tx;
  if (tw2 > 0) { fb.rrect(tx, y, tw2, 4, 2, 0.5, true); fb.fill(x + w - 3, y + 1, 2, 2, 1); }
}
static void progressWavy(FB &fb, int x, int y, int w, float v, float ph, float amp = 2) {
  v = clampf(v, 0, 1); int a = (int)roundf((w - 6) * v);
  for (int i = 0; i < a; i++) {
    float e = fminf(1, fminf(i / 6.f, (a - i) / 6.f));
    fb.disc(x + i + 0.5f, y + 0.5f + sinf(i / 10.f * 2 * PI - ph) * amp * e, 1.1, 1);
  }
  if (a < w - 3) fb.rrect(x + a + 3, y - 1, w - a - 3, 3, 1.5, 0.5, true);
}
static void progressRing(FB &fb, float cx, float cy, float r, float t, float v) {
  v = clampf(v, 0, 1); float deg = v * 360, g = (t / 2 + 3) / (2 * PI * (r - t / 2)) * 360;
  if (v > 0) fb.arcRound(cx, cy, r, t, 0, deg, 1);
  if (v < 1) { float s0 = v > 0 ? deg + g : 0, s1 = v > 0 ? 360 - g : 360; if (s1 > s0) fb.arc(cx, cy, r, t, s0, s1, 0.5); }
}
static void miniSwitch(FB &fb, int x, int y, float a) {
  fb.rrect(x, y, 16, 8, 4, 1, false);
  if (a > 0.15f) fb.rrect(x, y, 16, 8, 4, a > 0.85f ? 1 : 0.5f, true);
  fb.disc(x + 4 + a * 8, y + 4, 1.6f + a * 1.2f, a > 0.5f ? 0 : 1);
}
static float card(FB &fb, int x, int y, int w, int h, int v, float r = 6) {  // returns content colour
  fb.rrect(x, y, w, h, r, 0, true);
  if (v == CHIP_FILLED) { fb.rrect(x, y, w, h, r, 1, true); return 0; }
  if (v == CHIP_TONAL) { fb.rrect(x, y, w, h, r, 0.25, true); return 1; }
  fb.rrect(x, y, w, h, r, 1, false); return 1;
}

// ---------- rolling digits ----------
struct Roll { char id[6]; char str[8]; char pc[8]; uint32_t t[8]; int8_t d[8]; };
static Roll rolls[14];
static Roll *rollGet(const char *id, const char *str) {
  for (auto &r : rolls) if (r.id[0] && !strcmp(r.id, id)) {
    if (strlen(r.str) != strlen(str)) { strcpy(r.str, str); strcpy(r.pc, str); for (auto &t : r.t) t = 0; }
    return &r;
  }
  for (auto &r : rolls) if (!r.id[0]) { strncpy(r.id, id, 5); strcpy(r.str, str); strcpy(r.pc, str); for (auto &t : r.t) t = 0; for (auto &d : r.d) d = 1; return &r; }
  return &rolls[0];
}
struct TimeOpt { float u, r, lw; uint8_t h, m; int gap; float colon; int dir; int dur; };
static TLayout rollTime(FB &fb, const char *id, const char *str, int x, int y, TimeOpt o) {
  uint32_t now = millis(); Roll *r = rollGet(id, str);
  int n = strlen(str);
  if (strcmp(r->str, str)) {
    for (int i = 0; i < n; i++) if (str[i] != r->str[i]) { r->pc[i] = r->str[i]; r->t[i] = now + i * 30; r->d[i] = o.dir ? o.dir : 1; }
    strcpy(r->str, str);
  }
  TLayout L = timeLayout(str, o.u, o.r, o.gap ? o.gap : 3);
  int cx = x; bool after = false; int dur = o.dur ? o.dur : 340;
  for (int k = 0; k < n; k++) {
    char ch = str[k]; if (k) cx += L.g;
    if (ch == ':') {
      float rr = fmaxf(1.2f, o.r * 0.9f), tone = o.colon > 0 ? o.colon : 1;
      fb.disc(cx + L.cw / 2.f, y + L.H * 0.34f, rr, tone); fb.disc(cx + L.cw / 2.f, y + L.H * 0.66f, rr, tone);
      cx += L.cw; after = true; continue;
    }
    uint8_t st = after ? o.m : o.h;
    float p = r->t[k] == 0 ? 1 : clampf(((int32_t)(now - r->t[k])) / (float)dur, 0, 1);
    if ((int32_t)(now - r->t[k]) < 0) p = 0;
    if (p >= 1) glyph(fb, ch, cx, y, o.u, o.r, o.lw, st);
    else {
      float e = easeBack(p); int d = r->d[k], span = L.H + 2;
      glyph(fb, r->pc[k], cx, y, o.u, o.r, o.lw, st, (int)roundf(-d * e * span), y, y + L.H);
      glyph(fb, ch, cx, y, o.u, o.r, o.lw, st, (int)roundf(d * (1 - e) * span), y, y + L.H);
    }
    cx += L.W;
  }
  return L;
}
static TimeOpt TO(float u, float r, float lw, uint8_t h, uint8_t m, int dir = 1, int gap = 3, float colon = 1, int dur = 340) { TimeOpt o; o.u = u; o.r = r; o.lw = lw; o.h = h; o.m = m; o.dir = dir; o.gap = gap; o.colon = colon; o.dur = dur; return o; }

// ---------- vertical picker: rows scroll under a fixed XOR pill ----------
struct Spring { float pos, v; int target; };
static void springStep(Spring &s) {
  s.v = (s.v + (s.target - s.pos) * 0.3f) * 0.6f; s.pos += s.v;
  if (fabsf(s.v) < 0.002f && fabsf(s.target - s.pos) < 0.002f) { s.pos = s.target; s.v = 0; }
}
static void moveSpring(Spring &s, int d, int n) {
  int t = s.target + d;
  if (t < 0 || t > n - 1) { s.v += d * 0.32f; if (sndOn()) { beep(220, 50); beep(170, 60, 0.03); } return; }
  s.target = t;
  if (sndOn()) beep(1300 + (n > 1 ? (float)t / (n - 1) : 0) * 1100, 18);
}
struct PItem { const uint8_t *icon; const char *label; char sub[14]; float sw; };
static void picker(FB &fb, PItem *items, int n, Spring &sp, uint32_t t0) {
  springStep(sp);
  float pe = easeOut(clampf((millis() - t0) / 450.f, 0, 1));
  for (int i = 0; i < n; i++) {
    int top = (int)roundf(24 + (i - sp.pos) * 16); if (top < -16 || top > 64) continue;
    int dx = (int)roundf((1 - pe) * (26 + fabsf(i - sp.target) * 22));
    fb.icon(items[i].icon, 8 + dx, top + 4); fb.text(items[i].label, 21 + dx, top + 5);
    if (items[i].sw >= 0) miniSwitch(fb, 99 + dx, top + 4, items[i].sw);
    else if (items[i].sub[0]) fb.text(items[i].sub, 116 - textW(items[i].sub) + dx, top + 5);
  }
  fb.rrect(3, 24, 118, 16, 8, 2, true);
  for (int y = 2; y < 62; y += 2) fb.px(125, y, 1);
  int th = max(6, (int)roundf(60 * fminf(1, 4.f / n))), ty = 2 + (int)roundf((60 - th) * clampf(sp.pos / (n - 1), 0, 1));
  fb.rrect(124, ty, 3, th, 1.5, 1, true);
}
