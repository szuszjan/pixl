// PIXL — screens, faces, apps, transitions (port of MonoYouWatch/src/app.js)
#pragma once
#include "ui.h"
#include <sys/time.h>
#include <time.h>

// ---------- time ----------
struct Now { int h, m, s, ms, wday, mday, mon, year; };
static Now getNow() {
  struct timeval tv; gettimeofday(&tv, nullptr); struct tm t; localtime_r(&tv.tv_sec, &t);
  Now n = {t.tm_hour, t.tm_min, t.tm_sec, (int)(tv.tv_usec / 1000), t.tm_wday, t.tm_mday, t.tm_mon, t.tm_year + 1900};
  return n;
}
static const char *DAYS[7] = {"ND", "PN", "WT", "\x01R", "CZ", "PT", "SO"};
static const char *MON[12] = {"STY", "LUT", "MAR", "KWI", "MAJ", "CZE", "LIP", "SIE", "WRZ", "PAZ", "LIS", "GRU"};
static const char *MONF[12] = {"STYCZEN", "LUTY", "MARZEC", "KWIECIEN", "MAJ", "CZERWIEC", "LIPIEC", "SIERPIEN", "WRZESIEN", "PAZDZIERNIK", "LISTOPAD", "GRUDZIEN"};
static int dowOf(int y, int m, int d) { static const int t[] = {0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4}; if (m < 3) y -= 1; return (y + y / 4 - y / 100 + y / 400 + t[m - 1] + d) % 7; }
static int daysIn(int y, int m) { static const int d[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}; return m == 2 && ((y % 4 == 0 && y % 100) || y % 400 == 0) ? 29 : d[m - 1]; }

// ---------- settings & state ----------
struct Settings { uint8_t face = 0, contrast = 3, sleep = 1; bool aod = true, invert = false, sound = true, vibro = true; };
static Settings SET;
static const char *FACE_N[4] = {"HERO", "STACK", "RING", "ANALOG"};
static const uint8_t SLEEP_S[4] = {10, 15, 30, 0};
static const char *SLEEP_N[4] = {"10S", "15S", "30S", "NIGDY"};
static const char *CONTRAST_N[4] = {"25%", "50%", "75%", "100%"};
static const uint8_t CONTRAST_V[4] = {0x08, 0x30, 0x80, 0xFF};

enum Scr { SC_FACE, SC_MENU, SC_SW, SC_TIMER, SC_ALARM, SC_CAL, SC_MET, SC_BR, SC_DICE, SC_GAME, SC_LIFE, SC_FL, SC_SET, SC_N };
struct Trans { bool on; uint8_t type; int dir; uint32_t t0; float rx, ry, rw, rh, rr; uint8_t old[SW * SH / 8]; };
enum { TR_X, TR_Y, TR_IRIS, TR_IRISOUT };
struct Power { bool on; bool off; uint32_t t0; uint8_t src[SW * SH / 8]; };
enum AlertKind { AK_ALARM, AK_TIMER, AK_FIND, AK_NOTE };
struct Alert { bool on; AlertKind kind; uint32_t t0; char text[64]; };

static struct {
  Scr screen = SC_FACE; bool asleep = false, booting = true, offPending = false;
  uint32_t lastInput = 0, bootT0 = 0; int bootLetters = -1;
  // stopwatch
  bool swRun = false; uint32_t swT0 = 0, swAcc = 0, swLapT = 0; uint32_t laps[2] = {0, 0}; int lapN = 0; int swDir = 1;
  // timer
  int tmSet = 300; uint32_t tmLeft = 300000, tmEnd = 0; bool tmRun = false, tmStarted = false; int tmDir = 1;
  // alarm
  int alH = 7, alM = 0; bool alOn = true; int alField = -1, alEh = 7, alEm = 0, alDir = 1; time_t alSnooze = 0; int alLastFire = -1;
  // pickers
  Spring msp = {0, 0, 0}, ssp = {0, 0, 0}; uint32_t menuT0 = 0, setT0 = 0; float swa[5] = {-1, -1, -1, -1, -1};
  bool restartPending = false;
  int calY = 2026, calM = 11;
  int bpm = 100; bool metRun = false; uint32_t metT0 = 0; int metLast = -1, metDir = 1;
  int brPat = 0; bool brRun = false; uint32_t brT0 = 0; int brLastPh = -1;
  int diceN = 2; int diceShow[3] = {3, 5, 1}; int diceFin[3] = {0, 0, 0}; bool diceHas = false, diceRolling = false; uint32_t diceT0 = 0, diceTick = 0;
  int flMode = 0; uint32_t flT0 = 0, flLabelT = 0;
  int best = 0;
  uint32_t shakeT0 = 0, shakeDur = 0; float shakeMag = 0;
} S;
static Trans TR;
static Power PW;
static Alert AL;
static FB out, scr, disp;

static bool snd() { return SET.sound; }

// ---------- navigation ----------
static void enterScreen(Scr s, Scr prev);
static void go(Scr s, uint8_t type, int dir = 1, float rx = 3, float ry = 24, float rw = 118, float rh = 16) {
  memcpy(TR.old, out.b, sizeof(TR.old)); TR.on = true; TR.type = type; TR.dir = dir; TR.t0 = millis();
  TR.rx = rx; TR.ry = ry; TR.rw = rw; TR.rh = rh; TR.rr = 8;
  Scr prev = S.screen; S.screen = s; enterScreen(s, prev);
}
static void chirp(bool up) { if (!snd()) return; static const uint16_t a[] = {1500, 2000, 2700}, b[] = {2400, 1800, 1300}; for (int i = 0; i < 3; i++) beep(up ? a[i] : b[i], 30, i * 0.035f); }
static void back() { chirp(false); go(SC_MENU, TR_IRISOUT); }
static void shake(uint32_t dur, float mag) { S.shakeT0 = millis(); S.shakeDur = dur; S.shakeMag = mag; }
static void sleepScreen() {
  if (AL.on || S.asleep) return;
  memcpy(PW.src, out.b, sizeof(PW.src)); PW.on = true; PW.off = true; PW.t0 = millis();
  S.asleep = true; TR.on = false;
  if (snd()) beep(520, 120);
}
static void wakeScreen() { S.asleep = false; S.screen = SC_FACE; TR.on = false; PW.on = true; PW.off = false; PW.t0 = millis(); }
static void fireAlert(AlertKind k, const char *text = "") {
  S.asleep = false; PW.on = false; TR.on = false; AL.on = true; AL.kind = k; AL.t0 = millis();
  strncpy(AL.text, text, sizeof(AL.text) - 1); AL.text[sizeof(AL.text) - 1] = 0;
  S.lastInput = millis();
}
static float swAnim(int i, bool on) { float &a = S.swa[i]; if (a < 0) a = on ? 1 : 0; a += ((on ? 1 : 0) - a) * 0.28f; if (fabsf((on ? 1 : 0) - a) < 0.01f) a = on ? 1 : 0; return a; }
static uint32_t swElapsed() { return S.swAcc + (S.swRun ? millis() - S.swT0 : 0); }
static void fmtMS(char *o, int sec) { fmtHM(o, (sec / 60) % 100, sec % 60); }

// ---------- faces ----------
static void statusLeft(FB &fb) { if (S.alOn) { char t[6]; fmtHM(t, S.alH, S.alM); fb.icon(IC_BELL, 2, 0); fb.text(t, 12, 1); } }
static void datePL(char *o, const Now &n) { sprintf(o, "%s %d %s", DAYS[n.wday], n.mday, MON[n.mon]); }
static void faceHero(FB &fb, const Now &n) {
  statusLeft(fb); battery(fb, 113, 1, batteryLevel());
  char str[6]; fmtHM(str, n.h, n.m);
  TimeOpt o = TO(16, 3, 1.3, ST_SOLID, ST_OUTLINE, 1, 3, n.ms < 500 ? 1 : 0.5f);
  TLayout L = timeLayout(str, 16, 3);
  rollTime(fb, "hero", str, (SW - L.w) / 2, 11, o);
  char d[16]; datePL(d, n); int w = textW(d) + 10;
  chip(fb, (SW - w) / 2, 48, d, CHIP_TONAL);
  fb.hline(0, 63, (int)roundf(SW * (n.s + n.ms / 1000.f) / 60), 1);
}
static void faceStacked(FB &fb, const Now &n) {
  char a[3], b[3]; pad2(a, n.h); pad2(b, n.m);
  rollTime(fb, "stH", a, 4, 1, TO(15, 3, 1.3, ST_SOLID, ST_SOLID));
  rollTime(fb, "stM", b, 4, 33, TO(15, 3, 1.3, ST_OUTLINE, ST_OUTLINE));
  char t[12]; sprintf(t, "%s %d", DAYS[n.wday], n.mday); fb.text(t, 60, 3, 1, 2);
  fb.text(MONF[n.mon], 60, 21);
  if (S.alOn) { char al[6]; fmtHM(al, S.alH, S.alM); chip(fb, 60, 32, al, CHIP_OUTLINED, IC_BELL); }
  else { sprintf(t, "%d", n.year); fb.text(t, 60, 34); }
  progressBar(fb, 60, 49, 64, (n.s + n.ms / 1000.f) / 60);
  sprintf(t, "SEK %02d", n.s); fb.text(t, 60, 56);
}
static void faceRing(FB &fb, const Now &n) {
  progressRing(fb, 32, 32, 30, 5, fmaxf(0.004f, (n.s + n.ms / 1000.f) / 60));
  fb.text(DAYS[n.wday], 32 - textW(DAYS[n.wday], 2) / 2, 19, 1, 2);
  char ds[10]; sprintf(ds, "%d %s", n.mday, MON[n.mon]); fb.text(ds, 32 - textW(ds) / 2, 38);
  char a[3], b[3]; pad2(a, n.h); pad2(b, n.m);
  rollTime(fb, "rgH", a, 84, 4, TO(12, 3, 1.2, ST_SOLID, ST_SOLID));
  rollTime(fb, "rgM", b, 84, 34, TO(12, 3, 1.2, ST_TONAL, ST_TONAL));
}
static void faceAnalog(FB &fb, const Now &n) {
  float c = 31.5f;
  for (int k = 0; k < 60; k++) {
    float a = k * 6 * PI / 180, sx = sinf(a), sy = -cosf(a);
    if (k % 5 == 0) { bool big = k % 15 == 0; capsule(fb, c + sx * (big ? 21 : 24), c + sy * (big ? 21 : 24), c + sx * 28, c + sy * 28, big ? 1.3f : 0.8f); }
    else fb.px(c + sx * 29, c + sy * 29, 1);
  }
  float s = n.s + n.ms / 1000.f, m = n.m + s / 60, h = (n.h % 12) + m / 60;
  float ha = h * 30 * PI / 180, ma = m * 6 * PI / 180, sa = s * 6 * PI / 180;
  capsule(fb, c, c, c + sinf(ha) * 14, c - cosf(ha) * 14, 1.8f);
  capsule(fb, c, c, c + sinf(ma) * 22, c - cosf(ma) * 22, 1.2f);
  line(fb, roundf(c - sinf(sa) * 6), roundf(c + cosf(sa) * 6), roundf(c + sinf(sa) * 24), roundf(c - cosf(sa) * 24));
  fb.disc(c + sinf(sa) * 24, c - cosf(sa) * 24, 1.8f, 1); fb.disc(c, c, 3.2f, 1); fb.disc(c, c, 1.4f, 0);
  char t[16]; sprintf(t, "%s %d", DAYS[n.wday], n.mday); fb.text(t, 68, 6, 1, 2);
  sprintf(t, "%s %d", MON[n.mon], n.year); fb.text(t, 68, 24);
  fmtHM(t, n.h, n.m); fb.text(t, 68, 42, 1, 2);
}
static void faceAOD(FB &fb, const Now &n) {
  static const int8_t SH4[4][2] = {{0, 0}, {1, 0}, {1, 1}, {0, 1}};
  int sx = SH4[n.m % 4][0], sy = SH4[n.m % 4][1];
  char str[6]; fmtHM(str, n.h, n.m);
  TLayout L = timeLayout(str, 13, 2.5f);
  int x = (SW - L.w) / 2 + sx, cx = x;
  for (int k = 0; k < 5; k++) {
    if (k) cx += L.g;
    if (str[k] == ':') { fb.disc(cx + L.cw / 2.f, 14 + sy + L.H * 0.34f, 1.6f, 1); fb.disc(cx + L.cw / 2.f, 14 + sy + L.H * 0.66f, 1.6f, 1); cx += L.cw; }
    else { glyph(fb, str[k], cx, 14 + sy, 13, 2.5f, 1, ST_OUTLINE); cx += L.W; }
  }
  char d[16]; datePL(d, n); fb.text(d, (SW - textW(d)) / 2 + sx, 48 + sy);
}

// ---------- apps list ----------
struct App { Scr s; const char *name; const uint8_t *ic; };
static const App APPS[] = {
  {SC_SW, "STOPER", IC_STOPWATCH}, {SC_TIMER, "MINUTNIK", IC_HOURGLASS}, {SC_ALARM, "ALARM", IC_BELL}, {SC_CAL, "KALENDARZ", IC_CAL},
  {SC_MET, "METRONOM", IC_METRO}, {SC_BR, "ODDECH", IC_WIND}, {SC_DICE, "KOSTKA", IC_DICE}, {SC_GAME, "TUNEL", IC_SHIP},
  {SC_LIFE, "ZYCIE", IC_GLIDER}, {SC_FL, "LATARKA", IC_FLASH}, {SC_SET, "USTAWIENIA", IC_GEAR}};
static const int NAPPS = sizeof(APPS) / sizeof(APPS[0]);
struct Pat { const char *n; uint8_t p[4]; };
static const Pat PATS[3] = {{"KWADRAT", {4, 4, 4, 4}}, {"4-7-8", {4, 7, 8, 0}}, {"SPOKOJ", {5, 0, 5, 0}}};
static const char *PH_N[4] = {"WDECH", "TRZYMAJ", "WYDECH", "TRZYMAJ"};

static void appSub(int i, char *o) {
  o[0] = 0; Now n = getNow();
  switch (APPS[i].s) {
    case SC_SW: { uint32_t e = swElapsed(); if (S.swRun || e) fmtMS(o, e / 1000); } break;
    case SC_TIMER: if (!S.tmStarted) fmtMS(o, S.tmSet); else fmtMS(o, (int)ceilf((S.tmRun ? (int32_t)max((int32_t)0, (int32_t)(S.tmEnd - millis())) : (int32_t)S.tmLeft) / 1000.f)); break;
    case SC_ALARM: if (S.alOn) fmtHM(o, S.alH, S.alM); else strcpy(o, "WYL"); break;
    case SC_CAL: sprintf(o, "%d %s", n.mday, MON[n.mon]); break;
    case SC_MET: sprintf(o, "%d%s", S.bpm, S.metRun ? " >" : ""); break;
    case SC_BR: strcpy(o, PATS[S.brPat].n); break;
    case SC_DICE: sprintf(o, "%dK6", S.diceN); break;
    case SC_GAME: if (S.best) sprintf(o, "REK %d", S.best); break;
    default: break;
  }
}

// ---------- tunnel game ----------
static const char *SHIP[5] = {"11000000", "11110000", "11111111", "11110000", "11000000"};
struct Col { int8_t t, b; };
static struct { int mode; float y, vy, c, cv, sub; int dist, nextObs; uint32_t deadT; bool newBest; Col cols[SW]; struct { int x, y; } obs[8]; int nObs;
  struct { float x, y, vx, vy; int life; } parts[48]; int nParts; } GM;
enum { GM_TITLE, GM_PLAY, GM_DEAD };
static void gInit(int mode) {
  GM.mode = mode; GM.y = 32; GM.vy = 0; GM.dist = 0; GM.sub = 0; GM.c = 32; GM.cv = 0;
  for (int x = 0; x < SW; x++) GM.cols[x] = {10, 54};
  GM.nObs = 0; GM.nParts = 0; GM.nextObs = 140; GM.deadT = 0; GM.newBest = false;
}
static float frand() { return (esp_random() & 0xFFFF) / 65535.f; }
static Col gCol() {
  float gap = fmaxf(20, 44 - GM.dist / 110.f), half = gap / 2;
  GM.cv += (frand() - 0.5f) * 0.7f; GM.cv *= 0.93f; GM.c += GM.cv + (32 - GM.c) * 0.01f;
  if (GM.c < half + 2 || GM.c > SH - half - 2) GM.cv *= -0.5f;
  GM.c = clampf(GM.c, half + 2, SH - half - 2);
  return {(int8_t)roundf(GM.c - half), (int8_t)roundf(GM.c + half)};
}
static void addPart(float x, float y, float vx, float vy, int life) { if (GM.nParts < 48) GM.parts[GM.nParts++] = {x, y, vx, vy, life}; }
static void gStep() {
  float sp = GM.mode == GM_PLAY ? 1.2f + GM.dist / 2400.f : 1;
  GM.sub += sp;
  while (GM.sub >= 1) {
    GM.sub -= 1; memmove(GM.cols, GM.cols + 1, sizeof(Col) * (SW - 1)); GM.cols[SW - 1] = gCol();
    for (int i = 0; i < GM.nObs; i++) GM.obs[i].x--;
    GM.dist++;
    if (GM.mode == GM_PLAY && --GM.nextObs <= 0 && GM.nObs < 8) {
      Col c = GM.cols[SW - 1]; int yy = c.t + 3 + (int)(frand() * max(1, c.b - c.t - 14));
      GM.obs[GM.nObs++] = {SW, yy}; GM.nextObs = 70 + (int)(frand() * 60) - min(40, GM.dist / 100);
    }
  }
  int k = 0; for (int i = 0; i < GM.nObs; i++) if (GM.obs[i].x > -6) GM.obs[k++] = GM.obs[i]; GM.nObs = k;
}
static bool gHit(int yt) {
  for (int dy = 0; dy < 5; dy++) for (int dx = 0; dx < 8; dx++) {
    if (SHIP[dy][dx] != '1') continue;
    int X = 14 + dx, Y = yt + dy; Col c = GM.cols[X];
    if (Y <= c.t || Y >= c.b) return true;
    for (int i = 0; i < GM.nObs; i++) if (X >= GM.obs[i].x && X < GM.obs[i].x + 4 && Y >= GM.obs[i].y && Y < GM.obs[i].y + 8) return true;
  }
  return false;
}

// ---------- game of life ----------
static uint8_t lfA[64 * 32], lfAge[64 * 32], lfGhost[64 * 32], lfN[64 * 32];
static struct { uint32_t t, sweepT0, labelT; int speed = 1, same, last = -1; char label[16]; } LF;
static void lfSeed() { for (int i = 0; i < 64 * 32; i++) { lfA[i] = frand() < 0.3f; lfAge[i] = 0; lfGhost[i] = 0; } LF.same = 0; LF.sweepT0 = millis(); }
static void lfStep() {
  int cnt = 0;
  for (int y = 0; y < 32; y++) for (int x = 0; x < 64; x++) {
    int n = 0;
    for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) if (dx || dy) n += lfA[imod(y + dy, 32) * 64 + imod(x + dx, 64)];
    int i = y * 64 + x; bool alive = lfA[i] ? (n == 2 || n == 3) : n == 3;
    lfN[i] = alive; lfGhost[i] = lfA[i] && !alive; lfAge[i] = alive ? (lfA[i] ? min(9, lfAge[i] + 1) : 0) : 0; cnt += alive;
  }
  memcpy(lfA, lfN, sizeof(lfA));
  LF.same = cnt == LF.last ? LF.same + 1 : 0; LF.last = cnt;
  if (LF.same > 40 || cnt == 0) { lfSeed(); strcpy(LF.label, "NOWY SWIAT"); LF.labelT = millis(); }
}

static const uint8_t SOS[34] = {1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0};
static const float PIPS[7][6][2] = {{}, {{.5, .5}}, {{.27, .27}, {.73, .73}}, {{.27, .27}, {.5, .5}, {.73, .73}}, {{.27, .27}, {.73, .27}, {.27, .73}, {.73, .73}},
  {{.27, .27}, {.73, .27}, {.5, .5}, {.27, .73}, {.73, .73}}, {{.27, .27}, {.73, .27}, {.27, .5}, {.73, .5}, {.27, .73}, {.73, .73}}};
static void die(FB &fb, int x, int y, int s, int f) { fb.rrect(x, y, s, s, 5, 1, true); for (int i = 0; i < f; i++) fb.disc(x + PIPS[f][i][0] * s, y + PIPS[f][i][1] * s, s * 0.1f, 0); }
static int d6() { return 1 + (esp_random() % 6); }

// ---------- settings items ----------
static int settingsItems(PItem *it) {
  int n = 0;
  it[n] = {IC_FACE, "TARCZA", "", -1}; strcpy(it[n++].sub, FACE_N[SET.face]);
  it[n++] = {IC_MOON, "ALWAYS-ON", "", swAnim(0, SET.aod)};
  it[n] = {IC_CONTRAST, "KONTRAST", "", -1}; strcpy(it[n++].sub, CONTRAST_N[SET.contrast]);
  it[n] = {IC_HOURGLASS, "USPIENIE", "", -1}; strcpy(it[n++].sub, SLEEP_N[SET.sleep]);
  it[n++] = {IC_INVERT, "ODWROC", "", swAnim(1, SET.invert)};
  it[n++] = {IC_SPEAKER, "DZWIEK", "", swAnim(2, SET.sound)};
  it[n++] = {IC_VIBRO, "WIBRACJE", "", swAnim(3, SET.vibro)};
  it[n] = {IC_POWER, "RESTART", "", -1}; strcpy(it[n++].sub, ">");
  it[n] = {IC_INFO, "WERSJA", "", -1}; strcpy(it[n++].sub, "2.1");
  return n;
}

// ---------- PIXL boot ----------
static const char *PIXL_G[4][6] = {{"1110", "1001", "1001", "1110", "1000", "1000"}, {"1", "0", "1", "1", "1", "1"}, {"1001", "1001", "0110", "0110", "1001", "1001"}, {"1000", "1000", "1000", "1000", "1000", "1111"}};
struct PCell { uint8_t c, r, l; };
static PCell PCELLS[64]; static int NPC = 0, PCOLS = 0; static uint8_t PBITS[80 * 30];
static void initLogo() {
  int cx = 0; NPC = 0;
  for (int li = 0; li < 4; li++) { int w = strlen(PIXL_G[li][0]);
    for (int r = 0; r < 6; r++) for (int c = 0; c < w; c++) if (PIXL_G[li][r][c] == '1') PCELLS[NPC++] = {(uint8_t)(cx + c), (uint8_t)r, (uint8_t)li};
    cx += w + 1; }
  PCOLS = cx - 1;
  auto has = [](int c, int r) { for (int i = 0; i < NPC; i++) if (PCELLS[i].c == c && PCELLS[i].r == r) return true; return false; };
  memset(PBITS, 0, sizeof(PBITS));
  for (int i = 0; i < NPC; i++) { int cc = PCELLS[i].c, rr = PCELLS[i].r;
    for (int y = 0; y < 5; y++) for (int x = 0; x < 5; x++) {
      if (x == 0 && y == 0 && !has(cc - 1, rr) && !has(cc, rr - 1)) continue;
      if (x == 4 && y == 0 && !has(cc + 1, rr) && !has(cc, rr - 1)) continue;
      if (x == 0 && y == 4 && !has(cc - 1, rr) && !has(cc, rr + 1)) continue;
      if (x == 4 && y == 4 && !has(cc + 1, rr) && !has(cc, rr + 1)) continue;
      PBITS[(rr * 5 + y) * 80 + cc * 5 + x] = 1;
    } }
}
static const uint32_t BOOT_LEN = 3000;
static void dotCell(FB &fb, int x, int y) { fb.fill(x + 1, y, 2, 1); fb.fill(x, y + 1, 4, 2); fb.fill(x + 1, y + 3, 2, 1); }
static void startBoot() {
  AL.on = false; S.asleep = false; PW.on = false; TR.on = false; S.screen = SC_FACE;
  S.booting = true; S.bootT0 = millis(); S.bootLetters = -1; S.lastInput = millis();
  if (snd()) {
    static const uint16_t a[] = {523, 659, 784}; for (int i = 0; i < 3; i++) beep(a[i], 90, 0.36f + i * 0.09f);
    beep(1047, 250, 0.66f); beep(1568, 60, 2.65f); beep(2093, 60, 2.73f);
  }
  if (SET.vibro) vibrate(60, 0.66f);
}
// returns the mark rect for the final iris
static bool drawBoot(FB &fb, uint32_t el, const Now &n, float *rect) {
  int total = 28 + 7 + 80, x0 = (SW - total) / 2, BMX = x0 + 14, LX = x0 + 35, LY = 24 - 15;
  float e;
  if (el < 350) { e = easeOut(el / 350.f); fb.disc(64, 32, 0.6f + 2.4f * e, 1); return false; }
  if (el < 750) {
    e = easeOut((el - 350) / 400.f);
    float r = 3 + 11 * e, tone = e < 0.3f ? 0.25f : e < 0.6f ? 0.5f : e < 0.85f ? 0.75f : 1;
    fb.disc(64, 32, r, tone); fb.ring(64, 32, r, 1, 1);
    for (int k = 0; k < 8; k++) { float a = k / 8.f * 2 * PI + el / 160.f, rr = r + 4 + 6 * (1 - e); fb.px(64 + sinf(a) * rr, 32 - cosf(a) * rr, 1); }
    return false;
  }
  float pm = clampf((el - 750) / 400.f, 0, 1), rad = 14 - 8 * easeBack(pm);
  float ps = easeInOut(clampf(((int)el - 1150) / 400.f, 0, 1));
  int mx = (int)roundf(lerpf(64, BMX, ps)), my = (int)roundf(lerpf(32, 24, ps));
  fb.rrect(mx - 14, my - 14, 28, 28, fmaxf(4, rad), 1, true);
  float spin = 1 - easeOut(clampf((el - 750) / 900.f, 0, 1));
  float hA = ((n.h % 12) + n.m / 60.f) * 30 + spin * 720, mA = n.m * 6 + spin * 1440;
  capsule(fb, mx, my, mx + sinf(hA * PI / 180) * 6, my - cosf(hA * PI / 180) * 6, 1.4f, 0);
  capsule(fb, mx, my, mx + sinf(mA * PI / 180) * 9, my - cosf(mA * PI / 180) * 9, 1, 0);
  fb.disc(mx, my, 1.6f, 0);
  if (el > 2000) { float st = el < 2120 ? 0.25f : 0.5f; for (int y = 0; y < 30; y++) for (int x = 0; x < 80; x++) if (PBITS[y * 80 + x]) fb.px(LX + x + 2, LY + y + 2, st); }
  for (int i = 0; i < NPC; i++) {
    const PCell &cl = PCELLS[i];
    int d = (int)el - 1350 - cl.c * 30 - cl.r * 14 - ((i * 37) % 5) * 8; if (d < 0) continue;
    float q = clampf(d / 160.f, 0, 1); int bx = LX + cl.c * 5, by = LY + cl.r * 5;
    if (q < 1) { int sz = 1 + (int)(q * 5); int o = (5 - sz) / 2; fb.fill(bx + o, by + o - (q > 0.8f ? 1 : 0), sz, sz, 1); }
    else for (int yy = 0; yy < 5; yy++) for (int xx = 0; xx < 5; xx++) if (PBITS[(cl.r * 5 + yy) * 80 + cl.c * 5 + xx]) fb.px(bx + xx, by + yy, 1);
    if (cl.l > S.bootLetters) { S.bootLetters = cl.l; if (snd()) beep(1600 + cl.l * 260, 20); }
  }
  if (el > 2050) {
    float pl = easeInOut(clampf(((int)el - 2100) / 650.f, 0, 1)); int lit = (int)roundf(pl * PCOLS), y = LY + 30 + 5;
    for (int c = 0; c < PCOLS; c++) { if (c < lit) dotCell(fb, LX + c * 5, y); else fb.px(LX + c * 5 + 1, y + 1, 1); }
  }
  rect[0] = mx - 14; rect[1] = my - 14; rect[2] = 28; rect[3] = 28;
  return true;
}

// ---------- screens ----------
static void enterScreen(Scr s, Scr prev) {
  Now n = getNow();
  switch (s) {
    case SC_MENU: if (prev == SC_FACE) S.menuT0 = millis(); break;
    case SC_SET: if (prev == SC_MENU) S.setT0 = millis(); break;
    case SC_CAL: if (prev == SC_MENU) { S.calY = n.year; S.calM = n.mon; } break;
    case SC_GAME: gInit(GM_TITLE); break;
    case SC_LIFE: lfSeed(); LF.labelT = 0; break;
    case SC_FL: S.flT0 = S.flLabelT = millis(); break;
    default: break;
  }
}

static void drawScreen(FB &fb, const Now &n, float t) {
  uint32_t now = millis(); char buf[40];
  switch (S.screen) {
    case SC_FACE:
      if (SET.face == 0) faceHero(fb, n); else if (SET.face == 1) faceStacked(fb, n); else if (SET.face == 2) faceRing(fb, n); else faceAnalog(fb, n);
      break;
    case SC_MENU: {
      static PItem it[NAPPS];
      for (int i = 0; i < NAPPS; i++) { it[i].icon = APPS[i].ic; it[i].label = APPS[i].name; it[i].sw = -1; appSub(i, it[i].sub); }
      picker(fb, it, NAPPS, S.msp, S.menuT0);
    } break;
    case SC_SW: {
      uint32_t e = swElapsed(); int mm = (e / 60000) % 100, ss = (e / 1000) % 60, cs = (e / 10) % 100;
      fb.text("STOPER", 2, 1); if (S.lapN) { sprintf(buf, "OKR %d", S.lapN); rightText(fb, buf, 1); }
      uint8_t st = !S.swRun && e > 0 && ((int)(t * 2)) % 2 ? ST_OUTLINE : ST_SOLID;
      fmtHM(buf, mm, ss); rollTime(fb, "sw", buf, 12, 11, TO(13, 3, 1.2, st, st, S.swDir, 3, 1, 240));
      pad2(buf, cs); fb.text(buf, 111, 31);
      if (S.lapN) {
        uint32_t d = S.laps[1] - (S.lapN > 1 ? S.laps[0] : 0);
        int dx = (int)roundf((1 - easeOut(clampf((now - S.swLapT) / 320.f, 0, 1))) * 90);
        char a[8], b[3]; fmtMS(a, d / 1000); pad2(b, (d / 10) % 100); sprintf(buf, "OKR %d  %s,%s", S.lapN, a, b); fb.text(buf, 4 + dx, 42);
      }
      if (S.swRun) { Hint h[] = {{K_HASH, "STOP", true}, {K_DOWN, "OKRAZ", false}}; hints(fb, h, 2); }
      else if (e > 0) { Hint h[] = {{K_HASH, "START", true}, {K_DOWN, "ZERUJ", false}}; hints(fb, h, 2); }
      else { Hint h[] = {{K_HASH, "START", true}}; hints(fb, h, 1); }
    } break;
    case SC_TIMER: {
      uint32_t left = S.tmRun ? (uint32_t)max((int32_t)0, (int32_t)(S.tmEnd - now)) : S.tmLeft;
      int s = (int)ceilf(left / 1000.f); fmtMS(buf, s);
      TLayout L = timeLayout(buf, 13, 3); int x = (SW - L.w) / 2;
      fb.text("MINUTNIK", 2, 1);
      if (!S.tmStarted) {
        rollTime(fb, "tm", buf, x, 11, TO(13, 3, 1.2, ST_OUTLINE, ST_OUTLINE, S.tmDir));
        center(fb, "USTAW CZAS", 42);
        Hint h[] = {{K_UP, "+1", false}, {K_DOWN, "-1", false}, {K_HASH, "START", true}}; hints(fb, h, 3);
      } else {
        bool urgent = S.tmRun && s <= 10 && n.ms > 500, paused = !S.tmRun && ((int)(t * 2)) % 2;
        uint8_t st = urgent || paused ? ST_OUTLINE : ST_SOLID;
        rollTime(fb, "tm", buf, x, 11, TO(13, 3, 1.2, st, st, -1));
        progressWavy(fb, 4, 45, 120, left / (S.tmSet * 1000.f), S.tmRun ? t * 5 : 0);
        Hint h[] = {{K_HASH, S.tmRun ? "PAUZA" : "START", true}, {K_DOWN, "RESET", false}}; hints(fb, h, 2);
      }
    } break;
    case SC_ALARM: {
      bool ed = S.alField >= 0; int h = ed ? S.alEh : S.alH, m = ed ? S.alEm : S.alM;
      fb.text("ALARM", 2, 1); miniSwitch(fb, 108, 0, swAnim(4, S.alOn));
      bool blink = ((int)(t * 2.5f)) % 2;
      uint8_t hs = ed ? (S.alField == 0 && blink ? ST_OUTLINE : ST_SOLID) : (S.alOn ? ST_SOLID : ST_OUTLINE);
      uint8_t ms = ed ? (S.alField == 1 && blink ? ST_OUTLINE : ST_SOLID) : (S.alOn ? ST_SOLID : ST_OUTLINE);
      fmtHM(buf, h, m); TLayout L = timeLayout(buf, 13, 3);
      rollTime(fb, "al", buf, (SW - L.w) / 2, 11, TO(13, 3, 1.2, hs, ms, S.alDir));
      if (ed) center(fb, S.alField == 0 ? "GODZINA" : "MINUTY", 42);
      else if (S.alSnooze) { struct tm tt; localtime_r(&S.alSnooze, &tt); char a[6]; fmtHM(a, tt.tm_hour, tt.tm_min); sprintf(buf, "DRZEMKA %s", a); center(fb, buf, 42); }
      else if (S.alOn) { int diff = imod(S.alH * 60 + S.alM - (n.h * 60 + n.m), 1440); if (!diff) diff = 1440; sprintf(buf, "ZA %dH %dMIN", diff / 60, diff % 60); center(fb, buf, 42); }
      else center(fb, "WYLACZONY", 42);
      if (ed) { Hint hh[] = {{K_UP, "+", false}, {K_DOWN, "-", false}, {K_HASH, S.alField == 0 ? "DALEJ" : "ZAPISZ", true}}; hints(fb, hh, 3); }
      else { Hint hh[] = {{K_HASH, "EDYTUJ", true}, {K_DOWN, S.alOn ? "WYLACZ" : "WLACZ", false}}; hints(fb, hh, 2); }
    } break;
    case SC_CAL: {
      sprintf(buf, "%s %d", MONF[S.calM], S.calY); center(fb, buf, 1);
      const char *L = "PWSCPSN"; for (int i = 0; i < 7; i++) { char c[2] = {L[i], 0}; tiny(fb, c, 1 + i * 18 + 8, 10); }
      for (int gx = 4; gx < 124; gx += 2) fb.px(gx, 16, 1);
      int off = imod(dowOf(S.calY, S.calM + 1, 1) - 1, 7), days = daysIn(S.calY, S.calM + 1);
      bool isNow = n.year == S.calY && n.mon == S.calM;
      for (int d = 1; d <= days; d++) {
        int idx = off + d - 1, c = idx % 7, r = idx / 7, cx = 1 + c * 18 + 9, yy = 19 + r * 7;
        sprintf(buf, "%d", d); tiny(fb, buf, cx - ((int)strlen(buf) * 4 - 1) / 2, yy);
        if (isNow && d == n.mday) fb.rrect(cx - 7, yy - 2, 15, 9, 4.5, 2, true);
      }
    } break;
    case SC_MET: {
      float per = 60000.f / S.bpm; uint32_t el = now - S.metT0; int beat = -1;
      fb.text("METRONOM", 2, 1);
      sprintf(buf, "%d", S.bpm); rollTime(fb, "met", buf, 4, 12, TO(11, 3, 1.2, ST_SOLID, ST_SOLID, S.metDir, 2, 1, 220));
      fb.text("BPM", 4, 40);
      if (S.metRun) { beat = (int)(el / per); if (beat != S.metLast) { S.metLast = beat; if (snd()) beep(beat % 4 == 0 ? 2400 : 1600, 35); if (SET.vibro && beat % 4 == 0) vibrate(25); } }
      for (int i = 0; i < 4; i++) {
        int x = 7 + i * 11; bool on = S.metRun && imod(beat, 4) == i; float pulse = on ? 1 - clampf(fmodf(el, per) / 160.f, 0, 1) : 0;
        if (on) fb.disc(x, 55, 3 + pulse * 1.5f, 1); else fb.ring(x, 55, 3, 1, i == 0 ? 1 : 0.5f);
      }
      line(fb, 78, 63, 90, 4); line(fb, 114, 63, 102, 4); line(fb, 90, 4, 102, 4); fb.hline(76, 63, 40, 1);
      for (int yy = 20; yy < 60; yy += 6) fb.px(96, yy, 1);
      float ang = S.metRun ? cosf(el / per * PI) * 26 : 0, a = ang * PI / 180; float px = 96, py = 58;
      capsule(fb, px, py, px + sinf(a) * 46, py - cosf(a) * 46, 0.7f);
      float wd = 14 + (208 - S.bpm) / 168.f * 24;
      fb.rrect(roundf(px + sinf(a) * wd) - 4, roundf(py - cosf(a) * wd) - 3, 9, 6, 2, 1, true);
      fb.disc(px, py, 2.5f, 1);
    } break;
    case SC_BR: {
      const Pat &p = PATS[S.brPat]; float cx = 64, cy = 28;
      fb.text(p.n, 2, 1);
      if (!S.brRun) {
        float r0 = 8 + 2 * sinf(t * 1.6f); fb.disc(cx, cy, r0, 0.5f); fb.ring(cx, cy, r0, 1, 1);
        Hint h[] = {{K_HASH, "START", true}, {K_UP, "", false}, {K_DOWN, "WZOR", false}}; hints(fb, h, 3); break;
      }
      int total = p.p[0] + p.p[1] + p.p[2] + p.p[3]; float el = fmodf((now - S.brT0) / 1000.f, total), acc = 0; int ph = 0;
      for (int i = 0; i < 4; i++) { if (el < acc + p.p[i]) { ph = i; break; } acc += p.p[i]; }
      float dur = p.p[ph], pp = dur ? (el - acc) / dur : 1, r;
      if (ph == 0) r = 6 + 16 * easeInOut(pp); else if (ph == 1) r = 22; else if (ph == 2) r = 22 - 16 * easeInOut(pp); else r = 6;
      if (ph != S.brLastPh) { S.brLastPh = ph; if (snd()) beep(ph == 0 ? 523 : ph == 2 ? 392 : 440, 120); if (SET.vibro) vibrate(40); }
      fb.disc(cx, cy, r, 0.5f); fb.ring(cx, cy, r, 1, 1);
      if (ph == 1 || ph == 3) fb.ring(cx, cy, r + 2 + 1.5f * sinf(t * 5), 1, 0.5f);
      float oa = pp * 2 * PI, orb = r + 4; fb.disc(cx + sinf(oa) * orb, cy - cosf(oa) * orb, 1.6f, 1);
      sprintf(buf, "%s %d", PH_N[ph], max(1, (int)ceilf(dur - (el - acc)))); center(fb, buf, 57);
    } break;
    case SC_DICE: {
      float p = clampf((now - S.diceT0) / 800.f, 0, 1); bool rolling = S.diceRolling && p < 1;
      if (rolling && now - S.diceTick > 70) { S.diceTick = now; for (int i = 0; i < 3; i++) S.diceShow[i] = d6(); if (snd()) beep(900 + esp_random() % 500, 12); }
      if (S.diceRolling && p >= 1) { S.diceRolling = false; for (int i = 0; i < 3; i++) S.diceShow[i] = S.diceFin[i]; shake(180, 2); if (snd()) beep(700, 50); if (SET.vibro) vibrate(50); }
      int nd = S.diceN, size = 26, gap = 8, total = nd * size + (nd - 1) * gap, x0 = (SW - total) / 2;
      for (int i = 0; i < nd; i++) {
        int bx = x0 + i * (size + gap), by = 10, sz = 26;
        if (rolling) { by -= (int)roundf(fabsf(sinf(p * PI * 3 + i * 0.8f)) * (1 - p) * 12); bx += (int)roundf(sinf(now / 40.f + i * 2) * (1 - p) * 3); if (((now / 70) + i) % 2) sz = 22; }
        int o = (26 - sz) / 2; die(fb, bx + o, by + o, sz, S.diceShow[i]);
      }
      if (!rolling && S.diceHas && nd > 1) { int sum = 0; for (int i = 0; i < nd; i++) sum += S.diceFin[i]; sprintf(buf, "SUMA %d", sum); center(fb, buf, 41); }
      Hint h[] = {{K_HASH, "RZUT", true}, {K_UP, "+", false}, {K_DOWN, "-", false}}; hints(fb, h, 3);
    } break;
    case SC_GAME: {
      if (GM.mode != GM_DEAD) gStep();
      if (GM.mode == GM_TITLE) { float tc = (GM.cols[22].t + GM.cols[22].b) / 2.f; GM.vy += clampf((tc - GM.y) * 0.05f, -0.4f, 0.4f); GM.vy *= 0.86f; GM.y += GM.vy; }
      if (GM.mode == GM_PLAY) {
        if (keyHeld(K_UP)) GM.vy -= 0.42f; if (keyHeld(K_DOWN)) GM.vy += 0.42f;
        GM.vy *= 0.86f; GM.y += GM.vy;
        if (gHit((int)roundf(GM.y) - 2)) {
          GM.mode = GM_DEAD; GM.deadT = now; shake(420, 3); if (SET.vibro) vibrate(250);
          for (int q = 0; q < 26; q++) { float an = frand() * 2 * PI, sp = 0.5f + frand() * 2.2f; addPart(18, GM.y, cosf(an) * sp, sinf(an) * sp, 18 + (int)(frand() * 16)); }
          int sc = GM.dist / 10; if (sc > S.best) { S.best = sc; GM.newBest = true; saveSettings(); }
          if (snd()) { beep(330, 180); beep(165, 300, 0.12f); }
        }
      }
      if (GM.mode != GM_DEAD) addPart(13, GM.y + (frand() - 0.5f) * 2, -1 - frand(), (frand() - 0.5f) * 0.4f, 9);
      for (int x = 0; x < SW; x++) { Col c = GM.cols[x]; if (c.t > 0) { fb.fill(x, 0, 1, c.t, 0.5f); fb.px(x, c.t, 1); } if (c.b < SH - 1) { fb.fill(x, c.b + 1, 1, SH - c.b - 1, 0.5f); fb.px(x, c.b, 1); } }
      for (int i = 0; i < GM.nObs; i++) fb.rrect(GM.obs[i].x, GM.obs[i].y, 4, 8, 1.5f, 1, true);
      int k = 0; for (int i = 0; i < GM.nParts; i++) { auto &p = GM.parts[i]; p.x += p.vx; p.y += p.vy; p.life--; if (p.life > 0) { fb.px(p.x, p.y, 1); GM.parts[k++] = p; } } GM.nParts = k;
      if (GM.mode != GM_DEAD) { int yt = (int)roundf(GM.y) - 2; for (int dy = 0; dy < 5; dy++) for (int dx = 0; dx < 8; dx++) if (SHIP[dy][dx] == '1') fb.px(14 + dx, yt + dy, 1); }
      if (GM.mode == GM_PLAY) { sprintf(buf, "%d", GM.dist / 10); fb.textHalo(buf, SW - 3 - textW(buf), 2); }
      if (GM.mode == GM_TITLE) {
        fb.textHalo("TUNEL", (SW - textW("TUNEL", 2)) / 2, 12 + (int)roundf(sinf(t * 2) * 2), 2);
        if (S.best) { sprintf(buf, "REKORD %d", S.best); fb.textHalo(buf, (SW - textW(buf)) / 2, 34); }
        Hint h[] = {{K_UP, "", false}, {K_DOWN, "STER", false}, {K_HASH, "START", true}}; hints(fb, h, 3);
      }
      if (GM.mode == GM_DEAD && now - GM.deadT > 450) {
        float e = easeBack(clampf((now - GM.deadT - 450) / 300.f, 0, 1)); int cy = (int)roundf(lerpf(70, 8, e));
        float col = card(fb, 20, cy, 88, 40, CHIP_FILLED);
        center(fb, "KONIEC", cy + 5, col); sprintf(buf, "WYNIK %d", GM.dist / 10); center(fb, buf, cy + 16, col);
        if (GM.newBest) { if (((int)(t * 3)) % 2) center(fb, "NOWY REKORD", cy + 27, col); }
        else { sprintf(buf, "REKORD %d", S.best); center(fb, buf, cy + 27, col); }
        if (e >= 1) { Hint h[] = {{K_HASH, "ZNOWU", true}}; hints(fb, h, 1); }
      }
    } break;
    case SC_LIFE: {
      static const uint16_t SPD[4] = {480, 240, 120, 60};
      if (now - LF.t > SPD[LF.speed]) { LF.t = now; lfStep(); }
      float sx = now - LF.sweepT0 < 450 ? easeOut((now - LF.sweepT0) / 450.f) * SW : SW + 1;
      for (int y = 0; y < 32; y++) for (int x = 0; x < 64; x++) {
        if (x * 2 > sx) continue; int i = y * 64 + x;
        if (lfA[i]) fb.fill(x * 2, y * 2, 2, 2, lfAge[i] == 0 ? 0.5f : 1); else if (lfGhost[i]) fb.fill(x * 2, y * 2, 2, 2, 0.25f);
      }
      if (sx <= SW) fb.vline((int)roundf(sx), 0, SH, 1);
      if (LF.labelT && now - LF.labelT < 1300) pillLabel(fb, LF.label, 51);
    } break;
    case SC_FL: {
      float e = clampf((now - S.flT0) / 380.f, 0, 1); bool on = true;
      if (S.flMode == 1) on = SOS[(now / 220) % 34];
      if (on) fb.fill(0, 0, SW, SH, e < 0.3f ? 0.25f : e < 0.6f ? 0.5f : e < 0.9f ? 0.75f : 1);
      if (now - S.flLabelT < 1500) { const char *s = S.flMode ? "SOS" : "STALE"; int w = textW(s) + 26, x = (SW - w) / 2; fb.rrect(x, 50, w, 11, 5.5, 0, true); kglyph(fb, K_DOWN, x + 5, 52, 1); fb.text(s, x + 14, 52, 1); }
    } break;
    case SC_SET: { static PItem it[10]; int nn = settingsItems(it); picker(fb, it, nn, S.ssp, S.setT0); } break;
    default: break;
  }
}

static void keyScreen(int k, bool rep) {
  uint32_t now = millis();
  switch (S.screen) {
    case SC_FACE:
      if (rep) return;
      if ((k == K_UP || k == K_DOWN) && snd()) { beep(k == K_UP ? 1900 : 1500, 20); beep(k == K_UP ? 2500 : 1100, 20, 0.03f); }
      if (k == K_UP) { SET.face = imod(SET.face - 1, 4); saveSettings(); go(SC_FACE, TR_Y, -1); }
      else if (k == K_DOWN) { SET.face = imod(SET.face + 1, 4); saveSettings(); go(SC_FACE, TR_Y, 1); }
      else if (k == K_HASH) { chirp(true); go(SC_MENU, TR_IRIS, 1, 50, 24, 28, 16); }
      else if (k == K_STAR) sleepScreen();
      break;
    case SC_MENU:
      if (k == K_UP) moveSpring(S.msp, -1, NAPPS);
      else if (k == K_DOWN) moveSpring(S.msp, 1, NAPPS);
      else if (rep) return;
      else if (k == K_HASH) { chirp(true); go(APPS[S.msp.target].s, TR_IRIS); }
      else if (k == K_STAR) { chirp(false); go(SC_FACE, TR_IRISOUT, 1, 50, 24, 28, 16); }
      break;
    case SC_SW:
      if (rep) return;
      if (k == K_HASH) { S.swDir = 1; if (S.swRun) { S.swAcc += now - S.swT0; S.swRun = false; } else { S.swT0 = now; S.swRun = true; } if (snd()) beep(1800, 30); }
      else if (k == K_DOWN) { if (S.swRun) { uint32_t e = swElapsed(); S.laps[0] = S.laps[1]; S.laps[1] = e; S.lapN++; S.swLapT = now; } else { S.swDir = -1; S.swAcc = 0; S.lapN = 0; S.laps[0] = S.laps[1] = 0; } }
      else if (k == K_STAR) back();
      break;
    case SC_TIMER:
      if (!S.tmStarted) {
        int st = rep ? 300 : 60;
        if (k == K_UP) { S.tmDir = 1; S.tmSet = min(99 * 60, S.tmSet + st); S.tmLeft = S.tmSet * 1000; }
        else if (k == K_DOWN) { S.tmDir = -1; S.tmSet = max(60, S.tmSet - st); S.tmLeft = S.tmSet * 1000; }
        else if (rep) return;
        else if (k == K_HASH) { S.tmStarted = true; S.tmRun = true; S.tmEnd = now + S.tmLeft; }
        else if (k == K_STAR) back();
      } else {
        if (rep) return;
        if (k == K_HASH) { if (S.tmRun) { S.tmLeft = (uint32_t)max((int32_t)0, (int32_t)(S.tmEnd - now)); S.tmRun = false; } else { S.tmEnd = now + S.tmLeft; S.tmRun = true; } }
        else if (k == K_DOWN) { S.tmDir = 1; S.tmStarted = false; S.tmRun = false; S.tmLeft = S.tmSet * 1000; }
        else if (k == K_STAR) back();
      }
      break;
    case SC_ALARM:
      if (S.alField >= 0) {
        int step = rep ? (S.alField == 1 ? 5 : 1) : 1;
        if (k == K_UP) { S.alDir = 1; if (S.alField == 0) S.alEh = imod(S.alEh + 1, 24); else S.alEm = imod(S.alEm + step, 60); }
        else if (k == K_DOWN) { S.alDir = -1; if (S.alField == 0) S.alEh = imod(S.alEh - 1, 24); else S.alEm = imod(S.alEm - step, 60); }
        else if (rep) return;
        else if (k == K_HASH) { if (S.alField == 0) S.alField = 1; else { S.alH = S.alEh; S.alM = S.alEm; S.alOn = true; S.alField = -1; S.alSnooze = 0; saveSettings(); if (snd()) { beep(1800, 50); beep(2400, 60, 0.07f); } } }
        else if (k == K_STAR) S.alField = -1;
      } else {
        if (rep) return;
        if (k == K_HASH) { S.alField = 0; S.alEh = S.alH; S.alEm = S.alM; }
        else if (k == K_DOWN) { S.alOn = !S.alOn; S.alSnooze = 0; saveSettings(); }
        else if (k == K_STAR) back();
      }
      break;
    case SC_CAL:
      if (rep) return;
      if (k == K_UP || k == K_DOWN) { int d = k == K_UP ? -1 : 1; S.calM += d; if (S.calM < 0) { S.calM = 11; S.calY--; } if (S.calM > 11) { S.calM = 0; S.calY++; } go(SC_CAL, TR_Y, d); }
      else if (k == K_HASH) { Now n = getNow(); int dir = (n.year * 12 + n.mon) - (S.calY * 12 + S.calM); if (dir) { S.calY = n.year; S.calM = n.mon; go(SC_CAL, TR_Y, dir > 0 ? 1 : -1); } }
      else if (k == K_STAR) back();
      break;
    case SC_MET:
      if (k == K_UP || k == K_DOWN) { int d = k == K_UP ? 1 : -1; S.metDir = d; S.bpm = constrain(S.bpm + d * (rep ? 5 : 1), 40, 208); if (S.metRun) { S.metT0 = now; S.metLast = -1; } }
      else if (rep) return;
      else if (k == K_HASH) { S.metRun = !S.metRun; S.metT0 = now; S.metLast = -1; }
      else if (k == K_STAR) { S.metRun = false; back(); }
      break;
    case SC_BR:
      if (rep) return;
      if (k == K_HASH) { S.brRun = !S.brRun; S.brT0 = now; S.brLastPh = -1; }
      else if (k == K_UP || k == K_DOWN) { S.brPat = imod(S.brPat + (k == K_UP ? -1 : 1), 3); S.brT0 = now; S.brLastPh = -1; }
      else if (k == K_STAR) { S.brRun = false; back(); }
      break;
    case SC_DICE:
      if (rep) return;
      if (k == K_HASH) { S.diceT0 = now; S.diceRolling = true; S.diceHas = true; for (int i = 0; i < 3; i++) S.diceFin[i] = d6(); }
      else if (k == K_UP) S.diceN = min(3, S.diceN + 1);
      else if (k == K_DOWN) S.diceN = max(1, S.diceN - 1);
      else if (k == K_STAR) back();
      break;
    case SC_GAME:
      if (rep) return;
      if (k == K_HASH && (GM.mode == GM_TITLE || (GM.mode == GM_DEAD && now - GM.deadT > 700))) { gInit(GM_PLAY); if (snd()) beep(1200, 50); }
      else if (k == K_STAR) back();
      break;
    case SC_LIFE:
      if (k == K_UP || k == K_DOWN) { LF.speed = constrain(LF.speed + (k == K_UP ? 1 : -1), 0, 3); sprintf(LF.label, "TEMPO %d/4", LF.speed + 1); LF.labelT = now; }
      else if (rep) return;
      else if (k == K_HASH) { lfSeed(); strcpy(LF.label, "NOWY SWIAT"); LF.labelT = now; }
      else if (k == K_STAR) back();
      break;
    case SC_FL:
      if (rep) return;
      if (k == K_UP || k == K_DOWN) { S.flMode ^= 1; S.flLabelT = now; }
      else if (k == K_STAR) back();
      break;
    case SC_SET: {
      const int n = 9;
      if (k == K_UP) moveSpring(S.ssp, -1, n);
      else if (k == K_DOWN) moveSpring(S.ssp, 1, n);
      else if (rep) return;
      else if (k == K_HASH) {
        int i = S.ssp.target; bool on = true;
        switch (i) {
          case 0: SET.face = imod(SET.face + 1, 4); break;
          case 1: SET.aod = !SET.aod; on = SET.aod; break;
          case 2: SET.contrast = imod(SET.contrast + 1, 4); break;
          case 3: SET.sleep = imod(SET.sleep + 1, 4); break;
          case 4: SET.invert = !SET.invert; on = SET.invert; break;
          case 5: SET.sound = !SET.sound; on = SET.sound; break;
          case 6: SET.vibro = !SET.vibro; on = SET.vibro; if (on) vibrate(80); break;
          case 7: saveSettings(); S.restartPending = true; return;  // restart: power FX, then reboot into the boot animation
          case 8: S.ssp.v += 0.25f; break;
        }
        if (snd() || i == 5) { beep(on ? 2200 : 1400, 30); if (i != 8) beep(on ? 2900 : 1000, 30, 0.04f); }
        saveSettings();
      } else if (k == K_STAR) back();
    } break;
    default: break;
  }
}

// ---------- alerts ----------
static void wrapText(const char *src, char lines[3][20], int &nl) {
  nl = 0; char word[32]; int wl = 0; char cur[20] = ""; const char *p = src;
  auto flush = [&]() { if (cur[0] && nl < 3) { strcpy(lines[nl++], cur); cur[0] = 0; } };
  while (true) {
    char c = *p;
    if (c == ' ' || c == 0) {
      word[wl] = 0;
      if (wl) {
        if ((int)strlen(cur) + (cur[0] ? 1 : 0) + wl > 18) flush();
        if (wl > 18) word[18] = 0;
        if (cur[0]) strcat(cur, " "); strcat(cur, word);
      }
      wl = 0; if (!c) break;
    } else if (wl < 31) word[wl++] = c;
    p++;
  }
  flush();
}
static void drawAlert(FB &fb, float t) {
  uint32_t el = millis() - AL.t0; char buf[24];
  if (AL.kind == AK_NOTE) {
    float e = easeOut(clampf(el / 260.f, 0, 1)); int y = (int)roundf(-60 + e * 64);
    float col = card(fb, 4, y, 120, 54, CHIP_FILLED);
    fb.icon(IC_BELL, 10, y + 6, col); fb.text("WIADOMOSC", 22, y + 7, col);
    char lines[3][20]; int nl; wrapText(AL.text, lines, nl);
    for (int i = 0; i < nl; i++) fb.text(lines[i], 10, y + 20 + i * 10, col);
    return;
  }
  fb.fill(0, 0, SW, SH, 1);
  int wig = (int)roundf(sinf(t * 28) * 2 * (((int)(t * 1.5f)) % 2));
  const uint8_t *ic = AL.kind == AK_TIMER ? IC_HOURGLASS : IC_BELL;
  fb.icon(ic, 56 + wig, 3, 0, 2);
  if (AL.kind == AK_ALARM) {
    center(fb, "ALARM", 22, 0, 2); fmtHM(buf, S.alH, S.alM); center(fb, buf, 40, 0);
    Hint h[] = {{K_HASH, "STOP", true}, {K_DOWN, "DRZEMKA", false}}; hints(fb, h, 2, true, 52);
  } else if (AL.kind == AK_TIMER) {
    center(fb, "KONIEC", 22, 0, 2); center(fb, "MINUTNIK", 40, 0);
    Hint h[] = {{K_HASH, "OK", true}}; hints(fb, h, 1, true, 52);
  } else {
    center(fb, "TU JESTEM", 26, 0, 2); center(fb, "TELEFON CIE SZUKA", 46, 0);
  }
}
static void alertKey(int k) {
  AlertKind kd = AL.kind; AL.on = false;
  if (kd == AK_ALARM) { if (k == K_DOWN) { time_t now = time(nullptr); S.alSnooze = now + 5 * 60; } else S.alSnooze = 0; }
}
static uint32_t alertBeepT = 0;
static void alertService() {
  if (!AL.on) return;
  uint32_t el = millis() - AL.t0;
  if (AL.kind == AK_NOTE) { if (el > 6000) AL.on = false; return; }
  if (AL.kind == AK_FIND && el > 5000) { AL.on = false; return; }
  if (millis() - alertBeepT >= 1000 || el < 20) {
    alertBeepT = millis();
    if (snd() || AL.kind == AK_FIND) { beep(2700, 70); beep(2700, 70, 0.13f); beep(2700, 70, 0.26f); }
    if (SET.vibro) { vibrate(120); vibrate(120, 0.25f); }
  }
}

// ---------- CRT power FX ----------
static void powerFX(const uint8_t *src, FB &dst, uint32_t now) {
  uint32_t t = now - PW.t0; dst.clear();
  auto hl = [&](float wB) { int x0 = (int)roundf(SW / 2 - wB / 2), x1 = (int)roundf(SW / 2 + wB / 2); for (int x = max(0, x0); x < min(SW, x1); x++) { dst.put(x, 31, 1); dst.put(x, 32, 1); } };
  auto squash = [&](float hB) {
    int hh = max(1, (int)roundf(hB)), top = (int)roundf(SH / 2 - hh / 2.f);
    for (int y = 0; y < hh; y++) { int sy = min(SH - 1, y * SH / hh), dy = top + y; if (dy < 0 || dy >= SH) continue; for (int x = 0; x < SW; x++) dst.put(x, dy, bufGet(src, x, sy)); }
    if (hh < 4) hl(SW);
  };
  if (PW.off) {
    if (t < 200) squash(SH * (1 - easeIn(t / 200.f)));
    else if (t < 330) hl(fmaxf(2, SW * (1 - easeIn((t - 200) / 130.f))));
    else if (t < 430) dst.disc(64, 32, 2.2f * (1 - (t - 330) / 100.f), 1);
    else PW.on = false;
  } else {
    if (t < 90) hl(SW * easeOut(t / 90.f));
    else if (t < 310) squash(fmaxf(2, SH * easeOut((t - 90) / 220.f)));
    else PW.on = false;
  }
}

// ---------- one frame ----------
static void composeFrame() {
  uint32_t now = millis(); Now n = getNow(); float t = now / 1000.f;
  out.clear(); scr.clear();
  if (S.booting) {
    float rect[4]; bool hasRect = drawBoot(out, now - S.bootT0, n, rect);
    if (now - S.bootT0 >= BOOT_LEN) {
      S.booting = false; S.screen = SC_FACE; S.lastInput = now;
      memcpy(TR.old, out.b, sizeof(TR.old)); TR.on = true; TR.type = TR_IRIS; TR.t0 = now;
      if (hasRect) { TR.rx = rect[0]; TR.ry = rect[1]; TR.rw = rect[2]; TR.rh = rect[3]; TR.rr = 6; }
    }
  } else if (AL.on) drawAlert(out, t);
  else if (S.asleep) { if (SET.aod && !(PW.on && PW.off)) faceAOD(out, n); }
  else {
    drawScreen(scr, n, t);
    if (TR.on) {
      uint32_t dur = TR.type >= TR_IRIS ? 280 : 200; float p = clampf((now - TR.t0) / (float)dur, 0, 1), e = easeOut(p);
      if (TR.type == TR_X || TR.type == TR_Y) {
        int span = TR.type == TR_X ? SW : SH, o1 = (int)roundf(-TR.dir * e * span), o2 = (int)roundf(TR.dir * (1 - e) * span);
        if (TR.type == TR_X) { out.blitFrom(TR.old, o1, 0); out.blitFrom(scr.b, o2, 0); } else { out.blitFrom(TR.old, 0, o1); out.blitFrom(scr.b, 0, o2); }
      } else {
        bool open = TR.type == TR_IRIS; float q = open ? e : 1 - e;
        float rx = lerpf(TR.rx, -2, q), ry = lerpf(TR.ry, -2, q), rw = lerpf(TR.rw, SW + 4, q), rh = lerpf(TR.rh, SH + 4, q), rr = lerpf(TR.rr, 10, q);
        const uint8_t *inner = open ? scr.b : TR.old, *outer = open ? TR.old : scr.b;
        for (int y = 0; y < SH; y++) for (int x = 0; x < SW; x++) out.put(x, y, inRR(x, y, rx, ry, rw, rh, rr) ? bufGet(inner, x, y) : bufGet(outer, x, y));
        if (p < 1) { out.rrect(roundf(rx), roundf(ry), roundf(rw), roundf(rh), rr, 0, false, 2); out.rrect(roundf(rx), roundf(ry), roundf(rw), roundf(rh), rr, 1, false); }
      }
      if (p >= 1) TR.on = false;
    } else memcpy(out.b, scr.b, sizeof(out.b));
  }
  // panel stage
  if (PW.on) { powerFX(PW.off ? PW.src : out.b, disp, now); if (!PW.on) memcpy(disp.b, out.b, sizeof(disp.b)); }
  else memcpy(disp.b, out.b, sizeof(disp.b));
  if (S.shakeDur) {
    float sp = (now - S.shakeT0) / (float)S.shakeDur;
    if (sp >= 1) S.shakeDur = 0;
    else {
      float mg = S.shakeMag * (1 - sp); int sx = (int)roundf((frand() - 0.5f) * 2 * mg), sy = (int)roundf((frand() - 0.5f) * 2 * mg);
      static uint8_t tmp[SW * SH / 8]; memcpy(tmp, disp.b, sizeof(tmp)); disp.clear(); disp.blitFrom(tmp, sx, sy);
    }
  }
  bool inv = SET.invert && !S.asleep && !S.booting;
  if (AL.on && AL.kind != AK_NOTE && ((now - AL.t0) / 450) % 2) inv = !inv;
  if (inv) disp.invert();
}
