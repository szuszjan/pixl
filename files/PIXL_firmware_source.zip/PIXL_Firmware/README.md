# PIXL — firmware 2.1

Firmware zegarka PIXL (2.2): Seeed XIAO ESP32-S3 + moduł OLED 0,96″ 128×64 z czterema przyciskami (**^ v ☰ ↩** — na płytce opisane ^ v # \*), DS3231, buzzer pasywny, silnik wibracyjny, Li-Po 250 mAh. Przeniesiony 1:1 z web-prototypu (`MonoYouWatch/`), w stylu Mono You.

## Okablowanie

| Element | XIAO | GPIO | Uwagi |
| --- | --- | --- | --- |
| OLED SDA, DS3231 SDA | D4 | 5 | wspólne I²C |
| OLED SCL, DS3231 SCL | D5 | 6 | |
| OLED VCC, DS3231 VCC | 3V3 | — | |
| Przycisk ^ | D9 | 8 | do GND, pull-up wewnętrzny |
| Przycisk v | D7 | 44 | |
| Przycisk ☰ (#) | D2 | 3 | |
| Przycisk ↩ (\*) | D3 | 4 | |
| **Przycisk boczny (power)** | **D1** | **2** | kątowy tact 6×6 w lewej ściance, do GND; jedyny budzi z wyłączenia |
| Piezo (+) | D8 | 7 | drugi pin do GND |
| Silnik wibracyjny | D0 | 1 | przez tranzystor (niżej) |
| Dzielnik baterii | D10 | 9 | BAT+ — 33 kΩ — D10 — 33 kΩ — GND |
| Li-Po | pady BAT+/BAT− na spodzie XIAO | | XIAO ładuje z USB-C |

**Silnik:** D0 → 330 Ω → baza NPN (S9014, BC547, 2N2222), emiter do GND, kolektor do (−) silnika, (+) silnika do 3V3. Dioda 1N4148 równolegle do silnika, katodą do 3V3. (Albo MOSFET AO3400 z rezystorem 100 Ω na bramce i 100 kΩ bramka–GND.)

Z wyłączenia budzi tylko przycisk boczny na D1 (pin RTC). Przyciski z przodu nie włączą zegarka przypadkiem, np. o rękaw. D7 nie jest pinem RTC, a w tym układzie nie musi nim być.

## Ustawienia w kodzie (`PIXL_Firmware.ino`)

- `OLED_SH1106 1` — jeśli obraz jest przesunięty o 2 px albo ma śmieci na krawędzi (moduł z SH1106 zamiast SSD1306).
- `KEYS_ACTIVE_LOW 0` — jeśli przyciski modułu zwierają do VCC, a nie do GND.
- `I2C_HZ` — 800 kHz domyślnie; przy zakłóceniach 400000.
- Piny w `PIN_KEY[]`, `PIN_BUZZ`, `PIN_VIB`, `PIN_BAT`.

## Kompilacja i wgrywanie

Płytka `esp32:esp32:XIAO_ESP32S3` (rdzeń esp32 3.2.1), biblioteki: U8g2, NimBLE-Arduino 2.x.

```
arduino-cli compile --upload -p COMx --fqbn esp32:esp32:XIAO_ESP32S3 PIXL_Firmware
```

Jeśli port nie odpowiada: przytrzymaj BOOT na XIAO, wciśnij RESET, puść BOOT i wgraj ponownie.

## Zasilanie i przyciski

- **↩** — wstecz (na tarczy: uśpij ekran).
- **Przycisk boczny** krótko — uśpij / obudź ekran (przy alarmie: wyłącz alarm); **przytrzymaj 3 s — wyłącz** (głębokie uśpienie, ~kilkanaście µA).
- Wyłączony: **przytrzymaj przycisk boczny ~1 s**, by włączyć (krótkie dotknięcie nic nie robi). Start z animacją PIXL.
- Gdy alarm jest włączony, wyłączony zegarek sam się obudzi o godzinie alarmu i od razu zadzwoni.
- Czas trzyma DS3231 (także przy wyłączonym zegarku). Po pierwszym wgraniu ustawia się czas kompilacji; dokładny czas ustawia companion przez BLE.

## Protokół BLE (dla aplikacji companion)

Urządzenie `PIXL`, usługa `8f1d0001-6a2b-4b4e-9c3a-5049584c0001`.

- **CMD** `…0002` (write) — jedna komenda tekstowa na zapis:
  - `T<epoch>` — ustaw czas (sekundy lokalnego czasu ściennego, np. `Date.now()/1000 - offset*60`)
  - `M<tekst>` — wiadomość na ekranie (ASCII; bez polskich znaków)
  - `F` — znajdź zegarek
  - `R<min>` — uruchom minutnik
  - `A<h>,<m>,<on>` — ustaw alarm, np. `A7,30,1`
  - `S<klucz>=<wartość>` — `face` 0–3, `aod`, `contrast` 0–3, `sleep` 0–3, `invert`, `sound`, `vibro` (0/1)
- **STATE** `…0003` (read/notify co 5 s) — `bat=72;face=0;al=07:00,1;fw=2.1` (`bat=-1`, gdy nie ma dzielnika).

## Do zrobienia po złożeniu

- Sprawdzić pinout modułu ekranu i kierunek przycisków.
- Zmierzyć pobór prądu; uśpiony ekran z BLE to dziś pętla co 250 ms (bez light-sleep) — kolejny krok to light-sleep między klatkami always-on.
- Podłączyć companion przez Web Bluetooth do powyższego protokołu.
